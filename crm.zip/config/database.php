<?php
// /config/database.php
return [
    'host' => 'localhost',
    'dbname' => 'u3039253_crm_deps',
    'user' => 'u3039253_default',
    'password' => 'sRNmXf865heTNY4J',
    'charset' => 'utf8mb4'
];
?>