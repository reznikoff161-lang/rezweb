<?php
// ProjectsEditController.php

if (empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: ' . BASE_URL . '/projects');
    exit;
}

require_once 'models/Project.php';
require_once 'models/Client.php';
require_once 'models/Service.php';

$projectModel = new Project();
$clientModel = new Client();
$serviceModel = new Service();

$project_id = (int)$_GET['id'];
$project = $projectModel->getById($project_id);

if (!$project) {
    header('Location: ' . BASE_URL . '/projects');
    exit;
}

// Получаем списки клиентов и услуг
$clients = $clientModel->getAll();
$services = $serviceModel->getAll();

$errors = [];
$formData = [
    'name' => $project['name'],
    'description' => $project['description'],
    'client_name' => $project['client_name'],
    'client_id' => $project['client_id'],
    'service_id' => $project['service_id'],
    'price' => $project['price'],
    'status' => $project['status'],
    'deadline' => $project['deadline'],
    'start_date' => $project['start_date'],
    'is_recurring' => $project['is_recurring'],
    'recurrence_type' => $project['recurrence_type']
];

// Обработка формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $formData = [
        'name' => trim($_POST['name'] ?? ''),
        'description' => trim($_POST['description'] ?? ''),
        'client_name' => trim($_POST['client_name'] ?? ''),
        'client_id' => !empty($_POST['client_id']) ? (int)$_POST['client_id'] : null,
        'service_id' => !empty($_POST['service_id']) ? (int)$_POST['service_id'] : null,
        'price' => trim($_POST['price'] ?? '0'),
        'status' => $_POST['status'] ?? 'pending',
        'deadline' => $_POST['deadline'] ?? '',
        'start_date' => $_POST['start_date'] ?? date('Y-m-d'),
        'is_recurring' => isset($_POST['is_recurring']) ? 1 : 0,
        'recurrence_type' => $_POST['recurrence_type'] ?? ''
    ];

    // Валидация
    if (empty($formData['name'])) {
        $errors['name'] = 'Название проекта обязательно';
    }

    if (!empty($formData['price']) && !is_numeric(str_replace(',', '.', $formData['price']))) {
        $errors['price'] = 'Стоимость должна быть числом';
    }

    if (!empty($formData['deadline']) && strtotime($formData['deadline']) < time()) {
        $errors['deadline'] = 'Дедлайн не может быть в прошлом';
    }

    // Если выбран существующий клиент, очищаем ручное поле
    if (!empty($formData['client_id'])) {
        $formData['client_name'] = '';
    }

    // Если ошибок нет - сохраняем
    if (empty($errors)) {
        // Преобразуем price в число
        $formData['price'] = (float)str_replace(',', '.', $formData['price']);
        
        if ($projectModel->update($project_id, $formData)) {
            $_SESSION['success_message'] = 'Проект успешно обновлен!';
            header('Location: ' . BASE_URL . '/projects/view?id=' . $project_id);
            exit;
        } else {
            $errors['general'] = 'Ошибка при обновлении проекта';
        }
    }
}

$tpl = new Template('./views');
$tpl->assign('page_title', 'Редактировать проект - Моя CRM');
$tpl->assign('base_url', BASE_URL);
$tpl->assign('formData', $formData);
$tpl->assign('errors', $errors);
$tpl->assign('clients', $clients);
$tpl->assign('services', $services);
$tpl->assign('project', $project);

$content = $tpl->render('pages/projects/edit', true);

$layout = new Template('./views/layouts');
$layout->assign('page_title', 'Редактировать проект - Моя CRM');
$layout->assign('content', $content);
$layout->assign('current_page', 'projects');
$layout->render('auth');
?>