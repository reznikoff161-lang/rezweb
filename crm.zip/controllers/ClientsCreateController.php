<?php
// ClientsCreateController.php

if (empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

require_once 'models/Client.php';

$clientModel = new Client();

$errors = [];
$formData = [
    'name' => '',
    'email' => '',
    'phone' => '',
    'company' => '',
    'contact_person' => '',
    'notes' => ''
];

// Обработка формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $formData = [
        'name' => trim($_POST['name'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'phone' => trim($_POST['phone'] ?? ''),
        'company' => trim($_POST['company'] ?? ''),
        'contact_person' => trim($_POST['contact_person'] ?? ''),
        'notes' => trim($_POST['notes'] ?? '')
    ];

    // Валидация
    if (empty($formData['name'])) {
        $errors['name'] = 'Имя клиента обязательно';
    }

    if (!empty($formData['email']) && !filter_var($formData['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Некорректный email адрес';
    }

    // Если ошибок нет - сохраняем
    if (empty($errors)) {
        if ($clientModel->create($formData)) {
            $_SESSION['success_message'] = 'Клиент успешно создан!';
            header('Location: ' . BASE_URL . '/clients');
            exit;
        } else {
            $errors['general'] = 'Ошибка при создании клиента';
        }
    }
}

$tpl = new Template('./views');
$tpl->assign('page_title', 'Добавить клиента - Моя CRM');
$tpl->assign('base_url', BASE_URL);
$tpl->assign('formData', $formData);
$tpl->assign('errors', $errors);

$content = $tpl->render('pages/clients/create', true);

$layout = new Template('./views/layouts');
$layout->assign('page_title', 'Добавить клиента - Моя CRM');
$layout->assign('content', $content);
$layout->assign('current_page', 'clients');
$layout->render('auth');
?>