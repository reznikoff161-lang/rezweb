<?php
// StatisticsController.php

if (empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

require_once 'models/Transaction.php';
require_once 'models/Project.php';
require_once 'models/Client.php';
require_once 'models/Service.php';

$transactionModel = new Transaction();
$projectModel = new Project();
$clientModel = new Client();
$serviceModel = new Service();

// Параметры фильтрации
$selectedYear = $_GET['year'] ?? date('Y');
$selectedMonth = $_GET['month'] ?? '';
$selectedProject = $_GET['project_id'] ?? '';
$selectedClient = $_GET['client_id'] ?? '';

// Получаем данные для фильтров
$projects = $projectModel->getAll();
$clients = $clientModel->getAll();

// Получаем статистику
$stats = $transactionModel->getFinancialStats([
    'year' => $selectedYear,
    'month' => $selectedMonth,
    'project_id' => $selectedProject,
    'client_id' => $selectedClient
]);

$monthlyStats = $transactionModel->getMonthlyStats($selectedYear);
$topProjects = $transactionModel->getTopProjects(10, $selectedYear, $selectedMonth);
$serviceStats = $transactionModel->getServiceStats($selectedYear, $selectedMonth);

// Добавляем общую статистику
$stats['total_projects'] = count($projects);
$stats['total_clients'] = count($clients);

$tpl = new Template('./views');
$tpl->assign('page_title', 'Статистика - Моя CRM');
$tpl->assign('base_url', BASE_URL);
$tpl->assign('stats', $stats);
$tpl->assign('monthlyStats', $monthlyStats);
$tpl->assign('topProjects', $topProjects);
$tpl->assign('serviceStats', $serviceStats);
$tpl->assign('projects', $projects);
$tpl->assign('clients', $clients);
$tpl->assign('selectedYear', $selectedYear);
$tpl->assign('selectedMonth', $selectedMonth);
$tpl->assign('selectedProject', $selectedProject);
$tpl->assign('selectedClient', $selectedClient);

$content = $tpl->render('pages/statistics/index', true);

$layout = new Template('./views/layouts');
$layout->assign('page_title', 'Статистика - Моя CRM');
$layout->assign('content', $content);
$layout->assign('current_page', 'statistics');
$layout->render('auth');
?>