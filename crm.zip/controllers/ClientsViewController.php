<?php
// ClientsViewController.php

if (empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: ' . BASE_URL . '/clients');
    exit;
}

require_once 'models/Client.php';
require_once 'models/Project.php';

$clientModel = new Client();
$projectModel = new Project();

$client_id = (int)$_GET['id'];
$client = $clientModel->getById($client_id);

if (!$client) {
    header('Location: ' . BASE_URL . '/clients');
    exit;
}

// Получаем проекты клиента
$projects = $projectModel->getByClient($client_id);

$tpl = new Template('./views');
$tpl->assign('page_title', $client['name'] . ' - Моя CRM');
$tpl->assign('base_url', BASE_URL);
$tpl->assign('client', $client);
$tpl->assign('projects', $projects);

$content = $tpl->render('pages/clients/view', true);

$layout = new Template('./views/layouts');
$layout->assign('page_title', $client['name'] . ' - Моя CRM');
$layout->assign('content', $content);
$layout->assign('current_page', 'clients');
$layout->render('auth');
?>