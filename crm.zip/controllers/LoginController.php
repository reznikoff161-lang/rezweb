<?php
// LoginController.php

if (!empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/');
    exit;
}

require_once 'models/User.php';
$userModel = new User();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['login'] ?? '';
    $password = $_POST['password'] ?? '';
    
    // Ищем пользователя в БД
    $user = $userModel->findByUsername($username);
    
    if ($user && $userModel->verifyPassword($password, $user['password_hash'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_login'] = $user['username'];
        $_SESSION['user_role'] = $user['role'];
        
        header('Location: ' . BASE_URL . '/');
        exit;
    } else {
        $error = "Неверные логин или пароль";
    }
}

$tpl = new Template('./views');
$tpl->assign('page_title', 'Вход в систему');
$tpl->assign('error', $error);
$tpl->assign('base_url', BASE_URL);

$content = $tpl->render('pages/login', true);

$layout = new Template('./views/layouts');
$layout->assign('page_title', 'Вход в систему');
$layout->assign('content', $content);
$layout->render('guest');
?>