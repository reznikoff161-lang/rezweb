<?php
// FinanceEditController.php

if (empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: ' . BASE_URL . '/finance');
    exit;
}

require_once 'models/Transaction.php';
require_once 'models/Project.php';

$transactionModel = new Transaction();
$projectModel = new Project();

$transaction_id = (int)$_GET['id'];
$transaction = $transactionModel->getById($transaction_id);

if (!$transaction) {
    header('Location: ' . BASE_URL . '/finance');
    exit;
}

// Получаем список проектов для выпадающего меню
$projects = $projectModel->getAll();

$errors = [];
$formData = [
    'project_id' => $transaction['project_id'],
    'amount' => $transaction['amount'],
    'type' => $transaction['type'],
    'payment_method' => $transaction['payment_method'],
    'status' => $transaction['status'],
    'payment_date' => $transaction['payment_date'],
    'description' => $transaction['description']
];

// Обработка формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $formData = [
        'project_id' => (int)$_POST['project_id'],
        'amount' => trim($_POST['amount']),
        'type' => $_POST['type'],
        'payment_method' => $_POST['payment_method'],
        'status' => $_POST['status'],
        'payment_date' => $_POST['payment_date'],
        'description' => trim($_POST['description'])
    ];

    // Валидация
    if (empty($formData['project_id'])) {
        $errors['project_id'] = 'Выберите проект';
    }

    if (empty($formData['amount']) || !is_numeric($formData['amount']) || $formData['amount'] <= 0) {
        $errors['amount'] = 'Введите корректную сумму';
    }

    if (empty($formData['payment_date'])) {
        $errors['payment_date'] = 'Укажите дату платежа';
    }

    // Если ошибок нет - сохраняем
    if (empty($errors)) {
        $formData['amount'] = (float)$formData['amount'];
        
        if ($transactionModel->update($transaction_id, $formData)) {
            $_SESSION['success_message'] = 'Транзакция успешно обновлена!';
            header('Location: ' . BASE_URL . '/finance');
            exit;
        } else {
            $errors['general'] = 'Ошибка при обновлении транзакции';
        }
    }
}

$tpl = new Template('./views');
$tpl->assign('page_title', 'Редактировать транзакцию - Моя CRM');
$tpl->assign('base_url', BASE_URL);
$tpl->assign('formData', $formData);
$tpl->assign('errors', $errors);
$tpl->assign('projects', $projects);
$tpl->assign('transaction', $transaction);

$content = $tpl->render('pages/finance/edit', true);

$layout = new Template('./views/layouts');
$layout->assign('page_title', 'Редактировать транзакцию - Моя CRM');
$layout->assign('content', $content);
$layout->assign('current_page', 'finance');
$layout->render('auth');
?>