    <?php
// FinanceExportController.php

if (empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

require_once 'models/Transaction.php';

$transactionModel = new Transaction();

// Параметры фильтрации (те же что и в основном контроллере)
$filters = [
    'type' => $_GET['type'] ?? '',
    'status' => $_GET['status'] ?? '',
    'project_id' => $_GET['project_id'] ?? '',
    'date_from' => $_GET['date_from'] ?? '',
    'date_to' => $_GET['date_to'] ?? '',
    'search' => $_GET['search'] ?? ''
];

// Получаем данные для экспорта
$transactions = $transactionModel->getFilteredTransactions($filters);

// Устанавливаем заголовки для скачивания CSV
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=finance_export_' . date('Y-m-d') . '.csv');

// Создаем output stream
$output = fopen('php://output', 'w');

// Заголовки CSV
fputcsv($output, [
    'Дата',
    'Проект',
    'Клиент',
    'Тип',
    'Сумма',
    'Статус',
    'Способ оплаты',
    'Описание'
], ';');

// Данные
foreach ($transactions as $transaction) {
    fputcsv($output, [
        $transaction['payment_date'],
        $transaction['project_name'] ?? '',
        $transaction['client_name'] ?? '',
        $transaction['type'] == 'income' ? 'Доход' : 'Расход',
        $transaction['amount'],
        $transaction['status'] == 'completed' ? 'Завершено' : ($transaction['status'] == 'pending' ? 'Ожидает' : 'Отменено'),
        $transaction['payment_method'],
        $transaction['description'] ?? ''
    ], ';');
}

fclose($output);
exit;
?>