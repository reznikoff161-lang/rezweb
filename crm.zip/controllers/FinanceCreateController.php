<?php
// FinanceCreateController.php

if (empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

require_once 'models/Transaction.php';
require_once 'models/Project.php';

$transactionModel = new Transaction();
$projectModel = new Project();

// Получаем список проектов для выпадающего меню
$projects = $projectModel->getAll();

$errors = [];
$formData = [
    'project_id' => $_GET['project_id'] ?? '',
    'amount' => '',
    'type' => 'income',
    'payment_method' => 'bank_transfer',
    'status' => 'completed',
    'payment_date' => date('Y-m-d'),
    'description' => ''
];

// Обработка формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $formData = [
        'project_id' => (int)$_POST['project_id'],
        'amount' => trim($_POST['amount']),
        'type' => $_POST['type'],
        'payment_method' => $_POST['payment_method'],
        'status' => $_POST['status'],
        'payment_date' => $_POST['payment_date'],
        'description' => trim($_POST['description'])
    ];

    // Валидация
    if (empty($formData['project_id'])) {
        $errors['project_id'] = 'Выберите проект';
    }

    if (empty($formData['amount']) || !is_numeric($formData['amount']) || $formData['amount'] <= 0) {
        $errors['amount'] = 'Введите корректную сумму';
    }

    if (empty($formData['payment_date'])) {
        $errors['payment_date'] = 'Укажите дату платежа';
    }

    // Если ошибок нет - сохраняем
    if (empty($errors)) {
        $formData['amount'] = (float)$formData['amount'];
        
        if ($transactionModel->create($formData)) {
            $_SESSION['success_message'] = 'Транзакция успешно создана!';
            
            // Редирект в зависимости от источника
            if (isset($_GET['project_id'])) {
                header('Location: ' . BASE_URL . '/projects/view?id=' . $formData['project_id']);
            } else {
                header('Location: ' . BASE_URL . '/finance');
            }
            exit;
        } else {
            $errors['general'] = 'Ошибка при создании транзакции';
        }
    }
}

$tpl = new Template('./views');
$tpl->assign('page_title', 'Добавить транзакцию - Моя CRM');
$tpl->assign('base_url', BASE_URL);
$tpl->assign('formData', $formData);
$tpl->assign('errors', $errors);
$tpl->assign('projects', $projects);

$content = $tpl->render('pages/finance/create', true);

$layout = new Template('./views/layouts');
$layout->assign('page_title', 'Добавить транзакцию - Моя CRM');
$layout->assign('content', $content);
$layout->assign('current_page', 'finance');
$layout->render('auth');
?>