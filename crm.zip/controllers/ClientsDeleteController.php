<?php
// ClientsDeleteController.php

if (empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: ' . BASE_URL . '/clients');
    exit;
}

require_once 'models/Client.php';
require_once 'models/Project.php';

$clientModel = new Client();
$projectModel = new Project();

$client_id = (int)$_GET['id'];
$client = $clientModel->getById($client_id);

if (!$client) {
    header('Location: ' . BASE_URL . '/clients');
    exit;
}

// Проверяем, есть ли у клиента проекты
$clientProjects = $projectModel->getByClient($client_id);

if (!empty($clientProjects)) {
    $_SESSION['error_message'] = 'Нельзя удалить клиента, у которого есть проекты!';
    header('Location: ' . BASE_URL . '/clients/view?id=' . $client_id);
    exit;
}

// Удаляем клиента
if ($clientModel->delete($client_id)) {
    $_SESSION['success_message'] = 'Клиент успешно удален!';
} else {
    $_SESSION['error_message'] = 'Ошибка при удалении клиента';
}

header('Location: ' . BASE_URL . '/clients');
exit;
?>