<?php
// FinanceDeleteController.php

if (empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: ' . BASE_URL . '/finance');
    exit;
}

require_once 'models/Transaction.php';

$transactionModel = new Transaction();

$transaction_id = (int)$_GET['id'];
$transaction = $transactionModel->getById($transaction_id);

if (!$transaction) {
    header('Location: ' . BASE_URL . '/finance');
    exit;
}

// Удаляем транзакцию
if ($transactionModel->delete($transaction_id)) {
    $_SESSION['success_message'] = 'Транзакция успешно удалена!';
} else {
    $_SESSION['error_message'] = 'Ошибка при удалении транзакции';
}

// Редирект обратно на страницу, откуда пришли
if (isset($_SERVER['HTTP_REFERER'])) {
    header('Location: ' . $_SERVER['HTTP_REFERER']);
} else {
    header('Location: ' . BASE_URL . '/finance');
}
exit;
?>