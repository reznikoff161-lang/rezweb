<?php
// HomeController.php

if (empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

require_once 'models/Project.php';
require_once 'models/Transaction.php';

$projectModel = new Project();
$transactionModel = new Transaction();

// Статистика проектов
$projects = $projectModel->getAll();
$stats = [
    'total' => count($projects),
    'active' => 0,
    'completed' => 0,
    'overdue' => count($projectModel->getOverdueProjects()),
    'recurring' => count($projectModel->getRecurringProjects())
];

foreach ($projects as $project) {
    if ($project['status'] == 'active') $stats['active']++;
    if ($project['status'] == 'completed') $stats['completed']++;
}

// Финансовая статистика
$currentMonth = date('Y-m');
$currentYear = date('Y');

// Доход за месяц
$monthlyIncome = $transactionModel->getPeriodIncome($currentMonth . '-01', date('Y-m-t'));
// Доход за год
$yearlyIncome = $transactionModel->getPeriodIncome($currentYear . '-01-01', $currentYear . '-12-31');
// Ожидаемые платежи
$pendingIncome = $transactionModel->getPendingIncome();

$tpl = new Template('./views');
$tpl->assign('page_title', 'Дашборд - Моя CRM');
$tpl->assign('base_url', BASE_URL);
$tpl->assign('stats', $stats);
$tpl->assign('monthlyIncome', $monthlyIncome);
$tpl->assign('yearlyIncome', $yearlyIncome);
$tpl->assign('pendingIncome', $pendingIncome);

$content = $tpl->render('pages/dashboard', true);

$layout = new Template('./views/layouts');
$layout->assign('page_title', 'Дашборд  ');
$layout->assign('content', $content);
$layout->assign('current_page', 'home');
$layout->render('auth');
?>