<?php
// FinanceController.php

if (empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

require_once 'models/Transaction.php';
require_once 'models/Project.php';
require_once 'models/Client.php';

$transactionModel = new Transaction();
$projectModel = new Project();
$clientModel = new Client();

// Параметры фильтрации
$filters = [
    'type' => $_GET['type'] ?? '',
    'status' => $_GET['status'] ?? '',
    'project_id' => $_GET['project_id'] ?? '',
    'date_from' => $_GET['date_from'] ?? '',
    'date_to' => $_GET['date_to'] ?? '',
    'search' => $_GET['search'] ?? ''
];

// Получаем отфильтрованные транзакции
$transactions = $transactionModel->getFilteredTransactions($filters);
$pendingTransactions = $transactionModel->getPendingTransactions();

// Получаем списки для фильтров
$projects = $projectModel->getAll();
$clients = $clientModel->getAll();

// Считаем общую статистику (исправленный метод)
$stats = [
    'income' => 0,
    'expenses' => 0,
    'pending' => 0,
    'profit' => 0,
    'total' => count($transactions)
];

foreach ($transactions as $transaction) {
    if ($transaction['type'] === 'income') {
        if ($transaction['status'] === 'completed') {
            $stats['income'] += $transaction['amount'];
        } elseif ($transaction['status'] === 'pending') {
            $stats['pending'] += $transaction['amount'];
        }
    } elseif ($transaction['type'] === 'expense' && $transaction['status'] === 'completed') {
        $stats['expenses'] += $transaction['amount'];
    }
}

$stats['profit'] = $stats['income'] - $stats['expenses'];

$tpl = new Template('./views');
$tpl->assign('page_title', 'Финансы - Моя CRM');
$tpl->assign('base_url', BASE_URL);
$tpl->assign('transactions', $transactions);
$tpl->assign('pendingTransactions', $pendingTransactions);
$tpl->assign('stats', $stats);
$tpl->assign('filters', $filters);
$tpl->assign('projects', $projects);
$tpl->assign('clients', $clients);

$content = $tpl->render('pages/finance/index', true);

$layout = new Template('./views/layouts');
$layout->assign('page_title', 'Финансы - Моя CRM');
$layout->assign('content', $content);
$layout->assign('current_page', 'finance');
$layout->render('auth');
?>