<?php
// ProjectsViewController.php

if (empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: ' . BASE_URL . '/projects');
    exit;
}

require_once 'models/Project.php';
require_once 'models/Client.php';
require_once 'models/Service.php';
require_once 'models/Transaction.php'; // Добавляем эту строку

$projectModel = new Project(); // Сохраняем в переменную
$clientModel = new Client();
$serviceModel = new Service();
$transactionModel = new Transaction();

$project_id = (int)$_GET['id'];
$project = $projectModel->getById($project_id);

if (!$project) {
    header('Location: ' . BASE_URL . '/projects');
    exit;
}

// Получаем дополнительную информацию
$client = $project['client_id'] ? $clientModel->getById($project['client_id']) : null;
$service = $project['service_id'] ? $serviceModel->getById($project['service_id']) : null;

// Получаем транзакции проекта
$transactions = $transactionModel->getByProject($project_id);

// Рассчитываем прогресс дедлайна
$progress = 0;
if ($project['deadline'] && $project['start_date']) {
    $start = strtotime($project['start_date']);
    $end = strtotime($project['deadline']);
    $now = time();
    
    if ($end > $start) {
        $total = $end - $start;
        $passed = $now - $start;
        $progress = min(max(($passed / $total) * 100, 0), 100);
    }
}

$tpl = new Template('./views');
$tpl->assign('page_title', $project['name'] . ' - Моя CRM');
$tpl->assign('base_url', BASE_URL);
$tpl->assign('project', $project);
$tpl->assign('client', $client);
$tpl->assign('service', $service);
$tpl->assign('progress', $progress);
$tpl->assign('projectModel', $projectModel); // Добавляем эту строку
$tpl->assign('transactions', $transactions); // Добавляем эту строку

$content = $tpl->render('pages/projects/view', true);

$layout = new Template('./views/layouts');
$layout->assign('page_title', $project['name'] . ' - Моя CRM');
$layout->assign('content', $content);
$layout->assign('current_page', 'projects');
$layout->render('auth');
?>