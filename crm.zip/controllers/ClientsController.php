<?php
// ClientsController.php

if (empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

require_once 'models/Client.php';
require_once 'models/Project.php';

$clientModel = new Client();
$projectModel = new Project();

// Поиск клиентов
$search = $_GET['search'] ?? '';
if (!empty($search)) {
    $clients = $clientModel->search($search);
} else {
    $clients = $clientModel->getAll();
}

// Получаем количество проектов для каждого клиента
$clientStats = [];
foreach ($clients as $client) {
    $clientStats[$client['id']] = count($projectModel->getByClient($client['id']));
}

$tpl = new Template('./views');
$tpl->assign('page_title', 'Клиенты - Моя CRM');
$tpl->assign('base_url', BASE_URL);
$tpl->assign('clients', $clients);
$tpl->assign('clientStats', $clientStats);
$tpl->assign('search', $search);

$content = $tpl->render('pages/clients/index', true);

$layout = new Template('./views/layouts');
$layout->assign('page_title', 'Клиенты - Моя CRM');
$layout->assign('content', $content);
$layout->assign('current_page', 'clients');
$layout->render('auth');
?>