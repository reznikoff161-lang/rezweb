<?php
// ProjectsDeleteController.php

if (empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: ' . BASE_URL . '/projects');
    exit;
}

require_once 'models/Project.php';

$projectModel = new Project();

$project_id = (int)$_GET['id'];
$project = $projectModel->getById($project_id);

if (!$project) {
    header('Location: ' . BASE_URL . '/projects');
    exit;
}

// Удаляем проект
if ($projectModel->delete($project_id)) {
    $_SESSION['success_message'] = 'Проект успешно удален!';
} else {
    $_SESSION['error_message'] = 'Ошибка при удалении проекта';
}

header('Location: ' . BASE_URL . '/projects');
exit;
?>