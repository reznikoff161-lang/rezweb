<?php
// ClientsEditController.php

if (empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: ' . BASE_URL . '/clients');
    exit;
}

require_once 'models/Client.php';

$clientModel = new Client();

$client_id = (int)$_GET['id'];
$client = $clientModel->getById($client_id);

if (!$client) {
    header('Location: ' . BASE_URL . '/clients');
    exit;
}

$errors = [];
$formData = [
    'name' => $client['name'],
    'email' => $client['email'],
    'phone' => $client['phone'],
    'company' => $client['company'],
    'contact_person' => $client['contact_person'],
    'notes' => $client['notes']
];

// Обработка формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $formData = [
        'name' => trim($_POST['name'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'phone' => trim($_POST['phone'] ?? ''),
        'company' => trim($_POST['company'] ?? ''),
        'contact_person' => trim($_POST['contact_person'] ?? ''),
        'notes' => trim($_POST['notes'] ?? '')
    ];

    // Валидация
    if (empty($formData['name'])) {
        $errors['name'] = 'Имя клиента обязательно';
    }

    if (!empty($formData['email']) && !filter_var($formData['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Некорректный email адрес';
    }

    // Если ошибок нет - сохраняем
    if (empty($errors)) {
        if ($clientModel->update($client_id, $formData)) {
            $_SESSION['success_message'] = 'Клиент успешно обновлен!';
            header('Location: ' . BASE_URL . '/clients/view?id=' . $client_id);
            exit;
        } else {
            $errors['general'] = 'Ошибка при обновлении клиента';
        }
    }
}

$tpl = new Template('./views');
$tpl->assign('page_title', 'Редактировать клиента - Моя CRM');
$tpl->assign('base_url', BASE_URL);
$tpl->assign('formData', $formData);
$tpl->assign('errors', $errors);
$tpl->assign('client', $client);

$content = $tpl->render('pages/clients/edit', true);

$layout = new Template('./views/layouts');
$layout->assign('page_title', 'Редактировать клиента - Моя CRM');
$layout->assign('content', $content);
$layout->assign('current_page', 'clients');
$layout->render('auth');
?>