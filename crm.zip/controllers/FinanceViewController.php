<?php
// FinanceViewController.php

if (empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: ' . BASE_URL . '/finance');
    exit;
}

require_once 'models/Transaction.php';
require_once 'models/Project.php';
require_once 'models/Client.php';

$transactionModel = new Transaction();
$projectModel = new Project();
$clientModel = new Client();

$transaction_id = (int)$_GET['id'];
$transaction = $transactionModel->getById($transaction_id);

if (!$transaction) {
    header('Location: ' . BASE_URL . '/finance');
    exit;
}

// Получаем дополнительную информацию
$project = $projectModel->getById($transaction['project_id']);
$client = $project && $project['client_id'] ? $clientModel->getById($project['client_id']) : null;

$tpl = new Template('./views');
$tpl->assign('page_title', 'Транзакция #' . $transaction['id'] . ' - Моя CRM');
$tpl->assign('base_url', BASE_URL);
$tpl->assign('transaction', $transaction);
$tpl->assign('project', $project);
$tpl->assign('client', $client);

$content = $tpl->render('pages/finance/view', true);

$layout = new Template('./views/layouts');
$layout->assign('page_title', 'Транзакция #' . $transaction['id'] . ' - Моя CRM');
$layout->assign('content', $content);
$layout->assign('current_page', 'finance');
$layout->render('auth');
?>