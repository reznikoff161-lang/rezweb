<?php
// ProjectsController.php

if (empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login');
    exit;
}

require_once 'models/Project.php';
require_once 'models/Client.php';
require_once 'models/Service.php';

$projectModel = new Project();
$clientModel = new Client();
$serviceModel = new Service();

// Получаем все данные
$projects = $projectModel->getAll();
$clients = $clientModel->getAll();
$services = $serviceModel->getAll();

// Статистика
$stats = [
    'total' => count($projects),
    'active' => 0,
    'completed' => 0,
    'overdue' => count($projectModel->getOverdueProjects()),
    'recurring' => count($projectModel->getRecurringProjects())
];

foreach ($projects as $project) {
    if ($project['status'] == 'active') $stats['active']++;
    if ($project['status'] == 'completed') $stats['completed']++;
}

$tpl = new Template('./views');
$tpl->assign('page_title', 'Проекты');
$tpl->assign('base_url', BASE_URL);
$tpl->assign('projects', $projects);
$tpl->assign('clients', $clients);
$tpl->assign('services', $services);
$tpl->assign('stats', $stats);

$content = $tpl->render('pages/projects/index', true);

$layout = new Template('./views/layouts');
$layout->assign('page_title', 'Мои проекты ');
$layout->assign('content', $content);
$layout->assign('current_page', 'projects');
$layout->render('auth');
?>