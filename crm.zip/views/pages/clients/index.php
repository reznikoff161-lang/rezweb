<div class="row">
    <div class="col-12">
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-users me-2"></i>Клиенты</h3>
                <div class="d-flex gap-2">
                    <form method="GET" action="<?= $base_url ?>/clients" class="d-flex">
                        <input type="text" name="search" class="form-control form-control-sm" 
                            placeholder="Поиск клиентов..." value="<?= htmlspecialchars($search) ?>">

                    </form>
                    <a href="<?= $base_url ?>/clients/create" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus me-1"></i>Добавить клиента
                    </a>
                </div>
            </div>
            <div class="card-body">
                <?php if (empty($clients)): ?>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Клиентов пока нет. <a href="<?= $base_url ?>/clients/create">Добавьте первого клиента</a>.
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Клиент</th>
                                    <th>Контакты</th>
                                    <th>Компания</th>
                                    <th>Проектов</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($clients as $client): ?>
                                <tr>
                                    <td>
                                        <strong><?= htmlspecialchars($client['name']) ?></strong>
                                        <?php if (!empty($client['contact_person'])): ?>
                                            <br><small class="text-muted">Контакт: <?= htmlspecialchars($client['contact_person']) ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($client['email'])): ?>
                                            <div class="d-flex align-items-center mb-1">
                                                <i class="fas fa-envelope text-muted me-1" style="font-size: 0.8rem;"></i>
                                                <small><?= htmlspecialchars($client['email']) ?></small>
                                            </div>
                                        <?php endif; ?>
                                        <?php if (!empty($client['phone'])): ?>
                                            <div class="d-flex align-items-center">
                                                <i class="fas fa-phone text-muted me-1" style="font-size: 0.8rem;"></i>
                                                <small><?= htmlspecialchars($client['phone']) ?></small>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($client['company'])): ?>
                                            <?= htmlspecialchars($client['company']) ?>
                                        <?php else: ?>
                                            <span class="text-muted">Не указана</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-primary"><?= $clientStats[$client['id']] ?? 0 ?></span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?= $base_url ?>/clients/view?id=<?= $client['id'] ?>" class="btn btn-sm btn-outline-info">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?= $base_url ?>/clients/edit?id=<?= $client['id'] ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="<?= $base_url ?>/clients/delete?id=<?= $client['id'] ?>" 
                                               class="btn btn-sm btn-outline-danger" 
                                               onclick="return confirm('Удалить клиента?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>