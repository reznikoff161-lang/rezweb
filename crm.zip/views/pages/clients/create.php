<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="mb-0"><i class="fas fa-user-plus me-2"></i>Добавить клиента</h3>
            </div>
            <div class="card-body">
                <?php if (!empty($errors['general'])): ?>
                    <div class="alert alert-danger">
                        <?= htmlspecialchars($errors['general']) ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="<?= $base_url ?>/clients/create">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="name" class="form-label">Имя клиента *</label>
                                <input type="text" class="form-control <?= !empty($errors['name']) ? 'is-invalid' : '' ?>" 
                                       id="name" name="name" required 
                                       value="<?= htmlspecialchars($formData['name']) ?>"
                                       placeholder="ФИО или название компании">
                                <?php if (!empty($errors['name'])): ?>
                                    <div class="invalid-feedback"><?= htmlspecialchars($errors['name']) ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="company" class="form-label">Компания</label>
                                <input type="text" class="form-control" 
                                       id="company" name="company" 
                                       value="<?= htmlspecialchars($formData['company']) ?>"
                                       placeholder="Название компании">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control <?= !empty($errors['email']) ? 'is-invalid' : '' ?>" 
                                       id="email" name="email" 
                                       value="<?= htmlspecialchars($formData['email']) ?>"
                                       placeholder="email@example.com">
                                <?php if (!empty($errors['email'])): ?>
                                    <div class="invalid-feedback"><?= htmlspecialchars($errors['email']) ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="phone" class="form-label">Телефон</label>
                                <input type="tel" class="form-control" 
                                       id="phone" name="phone" 
                                       value="<?= htmlspecialchars($formData['phone']) ?>"
                                       placeholder="+7 (999) 999-99-99">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="contact_person" class="form-label">Контактное лицо</label>
                                <input type="text" class="form-control" 
                                       id="contact_person" name="contact_person" 
                                       value="<?= htmlspecialchars($formData['contact_person']) ?>"
                                       placeholder="ФИО контактного лица">
                            </div>
                        </div>
                    </div>

                    <div class="form-group mb-3">
                        <label for="notes" class="form-label">Заметки</label>
                        <textarea class="form-control" id="notes" name="notes" 
                                  rows="3" placeholder="Дополнительная информация о клиенте"><?= htmlspecialchars($formData['notes']) ?></textarea>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Создать клиента
                        </button>
                        <a href="<?= $base_url ?>/clients" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i>Отмена
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>