<div class="row">
    <div class="col-lg-8">
        <!-- Информация о клиенте -->
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><?= htmlspecialchars($client['name']) ?></h3>
                <div class="btn-group">
                    <a href="<?= $base_url ?>/clients/edit?id=<?= $client['id'] ?>" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-edit me-1"></i>Редактировать
                    </a>
                    <a href="<?= $base_url ?>/clients" class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-arrow-left me-1"></i>Назад
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <?php if (!empty($client['company'])): ?>
                            <div class="mb-3">
                                <strong>Компания:</strong><br>
                                <span class="text-muted"><?= htmlspecialchars($client['company']) ?></span>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($client['contact_person'])): ?>
                            <div class="mb-3">
                                <strong>Контактное лицо:</strong><br>
                                <span class="text-muted"><?= htmlspecialchars($client['contact_person']) ?></span>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-md-6">
                        <?php if (!empty($client['email'])): ?>
                            <div class="mb-3">
                                <strong>Email:</strong><br>
                                <span class="text-muted"><?= htmlspecialchars($client['email']) ?></span>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($client['phone'])): ?>
                            <div class="mb-3">
                                <strong>Телефон:</strong><br>
                                <span class="text-muted"><?= htmlspecialchars($client['phone']) ?></span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if (!empty($client['notes'])): ?>
                    <div class="mt-3">
                        <strong>Заметки:</strong>
                        <p class="text-muted"><?= nl2br(htmlspecialchars($client['notes'])) ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Проекты клиента -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Проекты клиента</h5>
            </div>
            <div class="card-body">
                <?php if (empty($projects)): ?>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        У клиента пока нет проектов.
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Проект</th>
                                    <th>Статус</th>
                                    <th>Стоимость</th>
                                    <th>Дедлайн</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($projects as $project): ?>
                                <tr>
                                    <td>
                                        <strong><?= htmlspecialchars($project['name']) ?></strong>
                                    </td>
                                    <td>
                                        <?php
                                        $status_badges = [
                                            'active' => ['success', 'Активный'],
                                            'completed' => ['secondary', 'Завершен'],
                                            'pending' => ['warning', 'Ожидание'],
                                            'cancelled' => ['danger', 'Отменен']
                                        ];
                                        ?>
                                        <span class="badge bg-<?= $status_badges[$project['status']][0] ?>">
                                            <?= $status_badges[$project['status']][1] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?= number_format($project['price'], 2, ',', ' ') ?> ₽
                                    </td>
                                    <td>
                                        <?= $project['deadline'] ? date('d.m.Y', strtotime($project['deadline'])) : 'Бессрочно' ?>
                                    </td>
                                    <td>
                                        <a href="<?= $base_url ?>/projects/view?id=<?= $project['id'] ?>" class="btn btn-sm btn-outline-info">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Боковая панель -->
    <div class="col-lg-4">
        <!-- Статистика -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Статистика</h5>
            </div>
            <div class="card-body">
                <div class="text-center">
                    <div class="bg-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" 
                         style="width: 80px; height: 80px;">
                        <i class="fas fa-briefcase text-white" style="font-size: 2rem;"></i>
                    </div>
                    <h4><?= count($projects) ?></h4>
                    <p class="text-muted">Проектов</p>
                </div>
            </div>
        </div>

        <!-- Действия -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Действия</h5>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="<?= $base_url ?>/projects/create?client_id=<?= $client['id'] ?>" class="btn btn-primary">
                        <i class="fas fa-plus me-1"></i>Новый проект
                    </a>
                    <a href="<?= $base_url ?>/clients/edit?id=<?= $client['id'] ?>" class="btn btn-outline-primary">
                        <i class="fas fa-edit me-1"></i>Редактировать
                    </a>
                    <button class="btn btn-outline-danger" onclick="if(confirm('Удалить клиента?')) window.location='<?= $base_url ?>/clients/delete?id=<?= $client['id'] ?>'">
                        <i class="fas fa-trash me-1"></i>Удалить
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>