<?php
// pages/login.php
?>
<div class="login-card card">
    <div class="card-header text-center">
        <h3 class="mb-2"><i class="fas fa-palette text-primary fa-2x"></i></h3>
        <h4 class="mb-1">CRM by Rezweb</h4>
        <p class="text-muted mb-0">Вход в CRM систему</p>
    </div>
    <div class="card-body">
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger mb-3">
                <i class="fas fa-exclamation-circle me-2"></i>
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="<?= $base_url ?>/login">
            <div class="form-group mb-3">
                <label for="login" class="form-label">Логин</label>
                <input type="text" class="form-control" id="login" name="login" required 
                       placeholder="Введите ваш логин" value="<?= htmlspecialchars($_POST['login'] ?? '') ?>">
            </div>
            <div class="form-group mb-4">
                <label for="password" class="form-label">Пароль</label>
                <input type="password" class="form-control" id="password" name="password" required 
                       placeholder="Введите ваш пароль">
            </div>
            <button type="submit" class="btn btn-primary w-100 py-2">
                <i class="fas fa-sign-in-alt me-2"></i>Войти
            </button>
        </form>
    </div>
</div>