<div class="row">
    <div class="col-12">
        <div class="card mb-4">
            <div class="card-header">
                <h3 class="mb-0"><i class="fas fa-chart-pie me-2"></i>Статистика</h3>
            </div>
            <div class="card-body">
                <!-- Фильтры -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <button class="btn btn-link p-0 text-decoration-none" type="button" data-bs-toggle="collapse" data-bs-target="#statsFilters">
                                <i class="fas fa-filter me-2"></i>Фильтры
                                <i class="fas fa-chevron-down ms-2 small"></i>
                            </button>
                        </h5>
                    </div>
                    <div class="collapse" id="statsFilters">
                        <div class="card-body">
                            <form method="GET" action="<?= $base_url ?>/statistics">
                                <div class="row g-3">
                                    <div class="col-md-3">
                                        <label class="form-label">Год</label>
                                        <select class="form-select" name="year">
                                            <?php for ($y = date('Y'); $y >= 2020; $y--): ?>
                                                <option value="<?= $y ?>" <?= $selectedYear == $y ? 'selected' : '' ?>><?= $y ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label">Месяц</label>
                                        <select class="form-select" name="month">
                                            <option value="">Все месяцы</option>
                                            <?php for ($m = 1; $m <= 12; $m++): ?>
                                                <option value="<?= $m ?>" <?= $selectedMonth == $m ? 'selected' : '' ?>>
                                                    <?= DateTime::createFromFormat('!m', $m)->format('F') ?>
                                                </option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label">Проект</label>
                                        <select class="form-select" name="project_id">
                                            <option value="">Все проекты</option>
                                            <?php foreach ($projects as $project): ?>
                                                <option value="<?= $project['id'] ?>" <?= $selectedProject == $project['id'] ? 'selected' : '' ?>>
                                                    <?= htmlspecialchars($project['name']) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label">Тип</label>
                                        <select class="form-select" name="type">
                                            <option value="">Все типы</option>
                                            <option value="income" <?= $selectedType == 'income' ? 'selected' : '' ?>>Доходы</option>
                                            <option value="expense" <?= $selectedType == 'expense' ? 'selected' : '' ?>>Расходы</option>
                                        </select>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="d-flex gap-2 mt-4">
                                            <button type="submit" class="btn btn-primary">
                                                <i class="fas fa-filter me-1"></i>Применить фильтры
                                            </button>
                                            <a href="<?= $base_url ?>/statistics" class="btn btn-secondary">
                                                <i class="fas fa-times me-1"></i>Сбросить
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Общая статистика -->
                <div class="stats-grid mb-4">
                    <div class="stat-card">
                        <div class="stat-number text-success"><?= number_format($stats['total_income'], 2, ',', ' ') ?> ₽</div>
                        <div class="stat-label">Общий доход</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number text-danger"><?= number_format($stats['total_expenses'], 2, ',', ' ') ?> ₽</div>
                        <div class="stat-label">Общие расходы</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number text-primary"><?= number_format($stats['profit'], 2, ',', ' ') ?> ₽</div>
                        <div class="stat-label">Прибыль</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-number"><?= $stats['total_transactions'] ?></div>
                        <div class="stat-label">Транзакций</div>
                    </div>
                </div>

                <!-- Статистика по месяцам -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Доходы и расходы по месяцам</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Месяц</th>
                                        <th>Доходы</th>
                                        <th>Расходы</th>
                                        <th>Прибыль</th>
                                        <th>Транзакций</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($monthlyStats as $month): ?>
                                    <tr>
                                        <td><?= DateTime::createFromFormat('!m', $month['month'])->format('F') ?> <?= $month['year'] ?></td>
                                        <td class="text-success"><?= number_format($month['income'], 2, ',', ' ') ?> ₽</td>
                                        <td class="text-danger"><?= number_format($month['expenses'], 2, ',', ' ') ?> ₽</td>
                                        <td class="<?= $month['profit'] >= 0 ? 'text-success' : 'text-danger' ?>">
                                            <?= number_format($month['profit'], 2, ',', ' ') ?> ₽
                                        </td>
                                        <td><?= $month['count'] ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Статистика по проектам -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Статистика по проектам</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Проект</th>
                                        <th>Клиент</th>
                                        <th>Доходы</th>
                                        <th>Расходы</th>
                                        <th>Прибыль</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($projectStats as $project): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($project['name']) ?></td>
                                        <td><?= htmlspecialchars($project['client_name'] ?? '—') ?></td>
                                        <td class="text-success"><?= number_format($project['income'], 2, ',', ' ') ?> ₽</td>
                                        <td class="text-danger"><?= number_format($project['expenses'], 2, ',', ' ') ?> ₽</td>
                                        <td class="<?= $project['profit'] >= 0 ? 'text-success' : 'text-danger' ?>">
                                            <?= number_format($project['profit'], 2, ',', ' ') ?> ₽
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Статистика по услугам -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Статистика по услугам</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Услуга</th>
                                        <th>Количество проектов</th>
                                        <th>Общий доход</th>
                                        <th>Средний чек</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($serviceStats as $service): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($service['name']) ?></td>
                                        <td><?= $service['project_count'] ?></td>
                                        <td class="text-success"><?= number_format($service['total_income'], 2, ',', ' ') ?> ₽</td>
                                        <td><?= number_format($service['avg_income'], 2, ',', ' ') ?> ₽</td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>