<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-edit me-2"></i>Редактировать проект</h3>
                <a href="<?= $base_url ?>/projects/view?id=<?= $project['id'] ?>" class="btn btn-outline-secondary btn-sm">
                    <i class="fas fa-arrow-left me-1"></i>Назад
                </a>
            </div>
            <div class="card-body">
                <?php if (!empty($errors['general'])): ?>
                    <div class="alert alert-danger">
                        <?= htmlspecialchars($errors['general']) ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="<?= $base_url ?>/projects/edit?id=<?= $project['id'] ?>">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="name" class="form-label">Название проекта *</label>
                                <input type="text" class="form-control <?= !empty($errors['name']) ? 'is-invalid' : '' ?>" 
                                       id="name" name="name" required 
                                       value="<?= htmlspecialchars($formData['name']) ?>">
                                <?php if (!empty($errors['name'])): ?>
                                    <div class="invalid-feedback"><?= htmlspecialchars($errors['name']) ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="service_id" class="form-label">Услуга *</label>
                                <select class="form-control" id="service_id" name="service_id" required>
                                    <option value="">-- Выберите услугу --</option>
                                    <?php foreach ($services as $service): ?>
                                        <option value="<?= $service['id'] ?>" 
                                            <?= $formData['service_id'] == $service['id'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($service['name']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-group mb-3">
                        <label for="description" class="form-label">Описание</label>
                        <textarea class="form-control" id="description" name="description" 
                                  rows="2" placeholder="Краткое описание проекта"><?= htmlspecialchars($formData['description']) ?></textarea>
                    </div>

                    <!-- Клиент и регулярность в одной строке -->
                    <div class="row">
                        <div class="col-md-8">
                            <div class="card mb-3">
                                <div class="card-body py-2">
                                    <div class="form-group mb-2">
                                        <label class="form-label">Клиент</label>
                                        <div class="row g-2">
                                            <div class="col-6">
                                                <select class="form-control form-control-sm" id="client_id" name="client_id" 
                                                        onchange="document.getElementById('client_name').value = ''">
                                                    <option value="">-- Выберите клиента --</option>
                                                    <?php foreach ($clients as $client): ?>
                                                        <option value="<?= $client['id'] ?>" 
                                                            <?= $formData['client_id'] == $client['id'] ? 'selected' : '' ?>>
                                                            <?= htmlspecialchars($client['name']) ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            <div class="col-6">
                                                <input type="text" class="form-control form-control-sm" 
                                                       id="client_name" name="client_name" 
                                                       value="<?= htmlspecialchars($formData['client_name']) ?>"
                                                       oninput="document.getElementById('client_id').value = ''"
                                                       placeholder="Новый клиент">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="card mb-3">
                                <div class="card-body py-2">
                                    <div class="form-group mb-2">
                                        <label class="form-label">Тип проекта</label>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="is_recurring" name="is_recurring" 
                                                   value="1" <?= $formData['is_recurring'] ? 'checked' : '' ?>
                                                   onchange="toggleRecurrence()">
                                            <label class="form-check-label" for="is_recurring">
                                                Регулярный
                                            </label>
                                        </div>
                                        <select class="form-control form-control-sm mt-1" id="recurrence_type" name="recurrence_type" 
                                                <?= !$formData['is_recurring'] ? 'disabled' : '' ?>>
                                            <option value="">-- Выберите --</option>
                                            <option value="monthly" <?= $formData['recurrence_type'] == 'monthly' ? 'selected' : '' ?>>Ежемесячно</option>
                                            <option value="quarterly" <?= $formData['recurrence_type'] == 'quarterly' ? 'selected' : '' ?>>Ежеквартально</option>
                                            <option value="yearly" <?= $formData['recurrence_type'] == 'yearly' ? 'selected' : '' ?>>Ежегодно</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Финансы и даты -->
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group mb-3">
                                <label for="price" class="form-label">Стоимость (₽)</label>
                                <input type="text" class="form-control <?= !empty($errors['price']) ? 'is-invalid' : '' ?>" 
                                       id="price" name="price" 
                                       value="<?= htmlspecialchars($formData['price']) ?>"
                                       placeholder="0.00">
                                <?php if (!empty($errors['price'])): ?>
                                    <div class="invalid-feedback"><?= htmlspecialchars($errors['price']) ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-md-3">
                            <div class="form-group mb-3">
                                <label for="status" class="form-label">Статус</label>
                                <select class="form-control" id="status" name="status">
                                    <option value="pending" <?= $formData['status'] == 'pending' ? 'selected' : '' ?>>Ожидание</option>
                                    <option value="active" <?= $formData['status'] == 'active' ? 'selected' : '' ?>>Активный</option>
                                    <option value="completed" <?= $formData['status'] == 'completed' ? 'selected' : '' ?>>Завершен</option>
                                    <option value="cancelled" <?= $formData['status'] == 'cancelled' ? 'selected' : '' ?>>Отменен</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-3">
                            <div class="form-group mb-3">
                                <label for="start_date" class="form-label">Дата начала</label>
                                <input type="date" class="form-control" 
                                       id="start_date" name="start_date" 
                                       value="<?= htmlspecialchars($formData['start_date']) ?>">
                            </div>
                        </div>
                        
                        <div class="col-md-3">
                            <div class="form-group mb-3">
                                <label for="deadline" class="form-label">Дедлайн</label>
                                <input type="date" class="form-control <?= !empty($errors['deadline']) ? 'is-invalid' : '' ?>" 
                                       id="deadline" name="deadline" 
                                       value="<?= htmlspecialchars($formData['deadline']) ?>">
                                <?php if (!empty($errors['deadline'])): ?>
                                    <div class="invalid-feedback"><?= htmlspecialchars($errors['deadline']) ?></div>
                                <?php endif; ?>
                                <small class="text-muted">Оставьте пустым для бессрочного</small>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Сохранить изменения
                        </button>
                        <a href="<?= $base_url ?>/projects/view?id=<?= $project['id'] ?>" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i>Отмена
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function toggleRecurrence() {
    const isRecurring = document.getElementById('is_recurring').checked;
    document.getElementById('recurrence_type').disabled = !isRecurring;
    if (!isRecurring) {
        document.getElementById('recurrence_type').value = '';
    }
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    toggleRecurrence();
});
</script>