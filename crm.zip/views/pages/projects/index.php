<div class="row">
    <div class="col-12">
     
<!-- Статистика -->
<div class="stats-grid mb-4">
    <div class="stat-card">
        <div class="stat-number stat-total"><?= $stats['total'] ?></div>
        <div class="stat-label">Всего</div>
    </div>
    <div class="stat-card">
        <div class="stat-number stat-active"><?= $stats['active'] ?></div>
        <div class="stat-label">Активные</div>
    </div>
    <div class="stat-card">
        <div class="stat-number stat-completed"><?= $stats['completed'] ?></div>
        <div class="stat-label">Завершены</div>
    </div>
    <div class="stat-card">
        <div class="stat-number stat-overdue"><?= $stats['overdue'] ?></div>
        <div class="stat-label">Просрочены</div>
    </div>
    <div class="stat-card">
        <div class="stat-number stat-recurring"><?= $stats['recurring'] ?></div>
        <div class="stat-label">Регулярные</div>
    </div>
    <div class="stat-card">
        <div class="stat-number stat-clients"><?= count($clients) ?></div>
        <div class="stat-label">Клиентов</div>
    </div>
</div>

        <div class="card mb-4">

            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-briefcase me-2"></i>Все проекты</h3>
                <a href="<?= $base_url ?>/projects/create" class="btn btn-primary btn-sm">
                    <i class="fas fa-plus me-1"></i>Новый проект
                </a>
            </div>
</div>
<div class="card mb-4">
   <div class="card-header">
        <h5 class="mb-0">
            <button class="btn btn-link p-0 text-decoration-none" type="button" data-bs-toggle="collapse" data-bs-target="#filtersCollapse">
                <i class="fas fa-filter me-2"></i>Фильтры
                <i class="fas fa-chevron-down ms-2 small"></i>
            </button>
        </h5>
 </div>

    <div class="collapse" id="filtersCollapse">
    <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-3">
                            <select class="form-select form-select-sm" onchange="filterByStatus(this.value)">
                                <option value="">Все статусы</option>
                                <option value="active">Активные</option>
                                <option value="pending">Ожидание</option>
                                <option value="completed">Завершенные</option>
                                <option value="cancelled">Отмененные</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select class="form-select form-select-sm" onchange="filterByService(this.value)">
                                <option value="">Все услуги</option>
                                <?php foreach ($services as $service): ?>
                                    <option value="<?= $service['id'] ?>"><?= htmlspecialchars($service['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select class="form-select form-select-sm" onchange="filterByClient(this.value)">
                                <option value="">Все клиенты</option>
                                <?php foreach ($clients as $client): ?>
                                    <option value="<?= $client['id'] ?>"><?= htmlspecialchars($client['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <input type="text" class="form-control form-control-sm" placeholder="Поиск..." onkeyup="searchProjects(this.value)">
                        </div>
                    </div>
                </div>
             </div>

        

            
            <div class="card-body">
                <?php if (empty($projects)): ?>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Проектов пока нет. <a href="<?= $base_url ?>/projects/create">Создайте первый проект</a>.
                    </div>
                <?php else: ?>
                    <!-- Фильтры -->






                    <div class="table-responsive">
                        <table class="table table-hover" id="projectsTable">
                            <thead>
                                <tr>
                                    <th>Проект</th>
                                    <th>Клиент</th>
                                    <th>Услуга</th>
                                    <th>Стоимость</th>
                                    <th>Статус</th>
                                    <th>Дедлайн</th>
                                    <th>Тип</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($projects as $project): ?>
                                <tr class="project-row" 
                                    data-status="<?= $project['status'] ?>"
                                    data-service="<?= $project['service_id'] ?>"
                                    data-client="<?= $project['client_id'] ?>">
                                    <td>
                                        <strong><?= htmlspecialchars($project['name']) ?></strong>
                                        <?php if (!empty($project['description'])): ?>
                                            <br><small class="text-muted"><?= htmlspecialchars(substr($project['description'], 0, 50)) ?>...</small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($project['client_company'])): ?>
                                            <?= htmlspecialchars($project['client_company']) ?>
                                        <?php elseif (!empty($project['client_name'])): ?>
                                            <?= htmlspecialchars($project['client_name']) ?>
                                        <?php else: ?>
                                            <span class="text-muted">Не указан</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($project['service_name'])): ?>
                                            <?= htmlspecialchars($project['service_name']) ?>
                                        <?php else: ?>
                                            <span class="text-muted">Не указана</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($project['price'] > 0): ?>
                                            <span class="fw-bold"><?= number_format($project['price'], 2, ',', ' ') ?> ₽</span>
                                        <?php else: ?>
                                            <span class="text-muted">Не указана</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                        $status_badges = [
                                            'active' => ['success', 'Активный'],
                                            'completed' => ['secondary', 'Завершен'],
                                            'pending' => ['warning', 'Ожидание'],
                                            'cancelled' => ['danger', 'Отменен']
                                        ];
                                        ?>
                                        <span class="badge bg-<?= $status_badges[$project['status']][0] ?>">
                                            <?= $status_badges[$project['status']][1] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($project['deadline']): ?>
                                            <?= date('d.m.Y', strtotime($project['deadline'])) ?>
                                            <?php if (strtotime($project['deadline']) < time() && !in_array($project['status'], ['completed', 'cancelled'])): ?>
                                                <br><small class="text-danger">Просрочен</small>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-muted">Бессрочно</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($project['is_recurring']): ?>
                                            <span class="badge bg-info">Регулярный</span>
                                            <?php if ($project['recurrence_type']): ?>
                                                <br><small class="text-muted">
                                                    <?php
                                                    $recurrence_types = [
                                                        'monthly' => 'Ежемесячно',
                                                        'quarterly' => 'Ежеквартально', 
                                                        'yearly' => 'Ежегодно'
                                                    ];
                                                    echo $recurrence_types[$project['recurrence_type']] ?? $project['recurrence_type'];
                                                    ?>
                                                </small>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Разовый</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?= $base_url ?>/projects/view?id=<?= $project['id'] ?>" class="btn btn-sm btn-outline-info">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?= $base_url ?>/projects/edit?id=<?= $project['id'] ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="<?= $base_url ?>/projects/delete?id=<?= $project['id'] ?>" 
                                            class="btn btn-sm btn-outline-danger" 
                                            onclick="return confirm('Удалить проект?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
function filterByStatus(status) {
    const rows = document.querySelectorAll('.project-row');
    rows.forEach(row => {
        if (!status || row.getAttribute('data-status') === status) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

function filterByService(serviceId) {
    const rows = document.querySelectorAll('.project-row');
    rows.forEach(row => {
        if (!serviceId || row.getAttribute('data-service') === serviceId) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

function filterByClient(clientId) {
    const rows = document.querySelectorAll('.project-row');
    rows.forEach(row => {
        if (!clientId || row.getAttribute('data-client') === clientId) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

function searchProjects(query) {
    const rows = document.querySelectorAll('.project-row');
    const searchTerm = query.toLowerCase();
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        if (text.includes(searchTerm)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}
</script>