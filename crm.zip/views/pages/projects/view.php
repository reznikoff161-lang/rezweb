<div class="row">
    <div class="col-lg-8">
        <!-- Основная информация -->
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><?= htmlspecialchars($project['name']) ?></h3>
                <div class="btn-group">
                    <a href="<?= $base_url ?>/projects/edit?id=<?= $project['id'] ?>" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-edit me-1"></i>Редактировать
                    </a>
                    <a href="<?= $base_url ?>/projects" class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-arrow-left me-1"></i>Назад
                    </a>
                </div>
            </div>
            <div class="card-body">
                <?php if (!empty($project['description'])): ?>
                    <div class="mb-4">
                        <h5>Описание</h5>
                        <p class="text-muted"><?= nl2br(htmlspecialchars($project['description'])) ?></p>
                    </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <strong>Услуга:</strong><br>
                            <span class="text-muted">
                                <?= $service ? htmlspecialchars($service['name']) : 'Не указана' ?>
                            </span>
                        </div>
                        
                        <div class="mb-3">
                            <strong>Статус:</strong><br>
                            <?php
                            $status_badges = [
                                'active' => ['success', 'Активный'],
                                'completed' => ['secondary', 'Завершен'],
                                'pending' => ['warning', 'Ожидание'],
                                'cancelled' => ['danger', 'Отменен']
                            ];
                            ?>
                            <span class="badge bg-<?= $status_badges[$project['status']][0] ?>">
                                <?= $status_badges[$project['status']][1] ?>
                            </span>
                        </div>
                        
                        <div class="mb-3">
                            <strong>Тип проекта:</strong><br>
                            <span class="text-muted">
                                <?= $project['is_recurring'] ? 'Регулярный' : 'Разовый' ?>
                                <?= $project['recurrence_type'] ? '(' . $project['recurrence_type'] . ')' : '' ?>
                            </span>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <strong>Стоимость:</strong><br>
                            <span class="fw-bold text-primary">
                                <?= number_format($project['price'], 2, ',', ' ') ?> ₽
                            </span>
                        </div>
                        
                        <div class="mb-3">
                            <strong>Дата начала:</strong><br>
                            <span class="text-muted">
                                <?= date('d.m.Y', strtotime($project['start_date'])) ?>
                            </span>
                        </div>
                        
                        <div class="mb-3">
                            <strong>Дедлайн:</strong><br>
                            <span class="text-muted">
                                <?= $project['deadline'] ? date('d.m.Y', strtotime($project['deadline'])) : 'Бессрочно' ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Прогресс бар дедлайна -->
        <?php if ($project['deadline']): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Прогресс по дедлайну</h5>
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-between mb-2">
                    <small>Начало: <?= date('d.m.Y', strtotime($project['start_date'])) ?></small>
                    <small>Дедлайн: <?= date('d.m.Y', strtotime($project['deadline'])) ?></small>
                </div>
                <div class="progress" style="height: 20px;">
                    <div class="progress-bar <?= $progress > 90 ? 'bg-danger' : ($progress > 70 ? 'bg-warning' : 'bg-success') ?>" 
                         role="progressbar" style="width: <?= $progress ?>%;" 
                         aria-valuenow="<?= $progress ?>" aria-valuemin="0" aria-valuemax="100">
                        <?= round($progress) ?>%
                    </div>
                </div>
                <div class="mt-2 text-center">
                    <small class="text-muted">
                        <?php
                        $days_left = ceil((strtotime($project['deadline']) - time()) / (60 * 60 * 24));
                        if ($days_left > 0) {
                            echo "Осталось $days_left " . getNounPluralForm($days_left, 'день', 'дня', 'дней');
                        } elseif ($days_left == 0) {
                            echo "Сегодня дедлайн!";
                        } else {
                            echo "Просрочено на " . abs($days_left) . " " . getNounPluralForm(abs($days_left), 'день', 'дня', 'дней');
                        }
                        ?>
                    </small>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Блок оплаты - ПЕРЕМЕЩАЕМ СЮДА -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-money-bill-wave me-2"></i>Финансовая информация</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <div class="text-center">
                            <h6>Общая стоимость</h6>
                            <h4 class="text-primary"><?= number_format($project['price'], 2, ',', ' ') ?> ₽</h4>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-center">
                            <h6>Оплачено</h6>
                            <h4 class="text-success"><?= number_format($projectModel->getTotalPaid($project['id']), 2, ',', ' ') ?> ₽</h4>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-center">
                            <h6>Остаток</h6>
                            <h4 class="<?= $projectModel->getBalance($project['id']) > 0 ? 'text-danger' : 'text-success' ?>">
                                <?= number_format($projectModel->getBalance($project['id']), 2, ',', ' ') ?> ₽
                            </h4>
                        </div>
                    </div>
                </div>

                <!-- Прогресс бар оплаты -->
                <?php 
                $total_paid = $projectModel->getTotalPaid($project['id']);
                $payment_percentage = $project['price'] > 0 ? ($total_paid / $project['price']) * 100 : 0;
                ?>
                <div class="mt-4">
                    <div class="d-flex justify-content-between mb-2">
                        <small>Прогресс оплаты</small>
                        <small><?= round($payment_percentage) ?>%</small>
                    </div>
                    <div class="progress" style="height: 20px;">
                        <div class="progress-bar 
                            <?= $payment_percentage == 100 ? 'bg-success' : ($payment_percentage > 0 ? 'bg-warning' : 'bg-danger') ?>" 
                             role="progressbar" style="width: <?= $payment_percentage ?>%;" 
                             aria-valuenow="<?= $payment_percentage ?>" aria-valuemin="0" aria-valuemax="100">
                            <?= round($payment_percentage) ?>%
                        </div>
                    </div>
                </div>

                <!-- Статус оплаты -->
                <div class="text-center mt-3">
                    <?php
                    $payment_status = $projectModel->getPaymentStatus($project['id']);
                    $status_badges = [
                        'paid' => ['success', 'Полностью оплачен'],
                        'partial' => ['warning', 'Частично оплачен'],
                        'unpaid' => ['danger', 'Не оплачен']
                    ];
                    ?>
                    <span class="badge bg-<?= $status_badges[$payment_status][0] ?>">
                        <?= $status_badges[$payment_status][1] ?>
                    </span>
                </div>
            </div>
        </div>
        <!-- История платежей -->
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="fas fa-history me-2"></i>История платежей</h5>
                <a href="<?= $base_url ?>/finance/create?project_id=<?= $project['id'] ?>" class="btn btn-sm btn-primary">
                    <i class="fas fa-plus me-1"></i>Добавить платеж
                </a>
            </div>
            <div class="card-body">
                <?php if (empty($transactions)): ?>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Платежей по проекту пока нет.
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Дата</th>
                                    <th>Сумма</th>
                                    <th>Тип</th>
                                    <th>Статус</th>
                                    <th>Описание</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($transactions as $transaction): ?>
                                <tr>
                                    <td><?= date('d.m.Y', strtotime($transaction['payment_date'])) ?></td>
                                    <td>
                                        <span class="fw-bold <?= $transaction['type'] === 'income' ? 'text-success' : 'text-danger' ?>">
                                            <?= number_format($transaction['amount'], 2, ',', ' ') ?> ₽
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($transaction['type'] === 'income'): ?>
                                            <span class="badge bg-success">Доход</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Расход</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                        $status_badges = [
                                            'pending' => ['warning', 'Ожидает'],
                                            'completed' => ['success', 'Завершено'],
                                            'cancelled' => ['danger', 'Отменено']
                                        ];
                                        ?>
                                        <span class="badge bg-<?= $status_badges[$transaction['status']][0] ?>">
                                            <?= $status_badges[$transaction['status']][1] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?= !empty($transaction['description']) ? htmlspecialchars($transaction['description']) : '—' ?>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?= $base_url ?>/finance/edit?id=<?= $transaction['id'] ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="<?= $base_url ?>/finance/delete?id=<?= $transaction['id'] ?>" 
                                               class="btn btn-sm btn-outline-danger" 
                                               onclick="return confirm('Удалить транзакцию?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>


        <!-- Файлы (будет реализовано позже) -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Файлы проекта</h5>
            </div>
            <div class="card-body">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    Функционал загрузки файлов будет добавлен в ближайшем обновлении.
                </div>
            </div>
        </div>
    </div>

    <!-- Боковая панель -->
    <div class="col-lg-4">
        <!-- Блок клиента -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Клиент</h5>
            </div>
            <div class="card-body">
                <?php if ($client): ?>
                    <div class="text-center mb-3">
                        <div class="bg-primary rounded-circle d-inline-flex align-items-center justify-content-center" 
                             style="width: 60px; height: 60px;">
                            <i class="fas fa-user text-white" style="font-size: 1.5rem;"></i>
                        </div>
                    </div>
                    
                    <h6 class="text-center"><?= htmlspecialchars($client['name']) ?></h6>
                    
                    <?php if (!empty($client['company'])): ?>
                        <p class="text-center text-muted mb-2"><?= htmlspecialchars($client['company']) ?></p>
                    <?php endif; ?>
                    
                    <div class="mt-3">
                        <?php if (!empty($client['email'])): ?>
                            <div class="d-flex align-items-center mb-2">
                                <i class="fas fa-envelope text-muted me-2"></i>
                                <small><?= htmlspecialchars($client['email']) ?></small>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($client['phone'])): ?>
                            <div class="d-flex align-items-center mb-2">
                                <i class="fas fa-phone text-muted me-2"></i>
                                <small><?= htmlspecialchars($client['phone']) ?></small>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($client['contact_person'])): ?>
                            <div class="d-flex align-items-center mb-2">
                                <i class="fas fa-user-tie text-muted me-2"></i>
                                <small>Контакт: <?= htmlspecialchars($client['contact_person']) ?></small>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="text-center mt-3">
                        <a href="<?= $base_url ?>/clients/view?id=<?= $client['id'] ?>" class="btn btn-outline-primary btn-sm">
                            <i class="fas fa-eye me-1"></i>Профиль клиента
                        </a>
                    </div>
                <?php elseif (!empty($project['client_name'])): ?>
                    <div class="text-center">
                        <i class="fas fa-user-tie fa-2x text-muted mb-3"></i>
                        <h6><?= htmlspecialchars($project['client_name']) ?></h6>
                        <p class="text-muted">Внешний клиент</p>
                    </div>
                <?php else: ?>
                    <div class="text-center text-muted">
                        <i class="fas fa-user-slash fa-2x mb-3"></i>
                        <p>Клиент не указан</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Действия -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Действия</h5>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="<?= $base_url ?>/projects/edit?id=<?= $project['id'] ?>" class="btn btn-primary">
                        <i class="fas fa-edit me-1"></i>Редактировать
                    </a>
                    <a href="<?= $base_url ?>/finance/create?project_id=<?= $project['id'] ?>" class="btn btn-success">
                        <i class="fas fa-money-bill me-1"></i>Добавить платеж
                    </a>
                    <button class="btn btn-outline-danger" onclick="if(confirm('Удалить проект?')) window.location='<?= $base_url ?>/projects/delete?id=<?= $project['id'] ?>'">
                        <i class="fas fa-trash me-1"></i>Удалить
                    </button>
                </div>
            </div>
        </div>

        <!-- Информация о проекте -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Информация</h5>
            </div>
            <div class="card-body">
                <div class="small text-muted">
                    <div class="d-flex justify-content-between mb-1">
                        <span>Создан:</span>
                        <span><?= date('d.m.Y H:i', strtotime($project['created_at'])) ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-1">
                        <span>Обновлен:</span>
                        <span><?= date('d.m.Y H:i', strtotime($project['updated_at'])) ?></span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span>ID:</span>
                        <span>#<?= $project['id'] ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Функция для правильного склонения существительных
function getNounPluralForm($number, $one, $two, $five) {
    $number = abs($number) % 100;
    if ($number > 10 && $number < 20) return $five;
    $number = $number % 10;
    if ($number > 1 && $number < 5) return $two;
    if ($number == 1) return $one;
    return $five;
}
?>