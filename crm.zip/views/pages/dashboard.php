<?php
// pages/dashboard.php
?>
<div class="row">
    <div class="col-12">
        <!-- Статистика -->
        <div class="stats-grid mb-4">
            <div class="stat-card">
                <div class="stat-number"><?= $stats['total'] ?></div>
                <div class="stat-label">Всего проектов</div>
            </div>
            <div class="stat-card">
                <div class="stat-number text-success"><?= $stats['active'] ?></div>
                <div class="stat-label">Активные</div>
            </div>
            <div class="stat-card">
                <div class="stat-number text-primary"><?= number_format($monthlyIncome, 2, ',', ' ') ?> ₽</div>
                <div class="stat-label">Доход за месяц</div>
            </div>
            <div class="stat-card">
                <div class="stat-number text-info"><?= number_format($yearlyIncome, 2, ',', ' ') ?> ₽</div>
                <div class="stat-label">Доход за год</div>
            </div>
            <div class="stat-card">
                <div class="stat-number text-warning"><?= number_format($pendingIncome, 2, ',', ' ') ?> ₽</div>
                <div class="stat-label">Ожидает оплаты</div>
            </div>
            <div class="stat-card">
                <div class="stat-number text-secondary"><?= $stats['completed'] ?></div>
                <div class="stat-label">Завершено</div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="mb-0"><i class="fas fa-tachometer-alt me-2"></i>Обзор</h3>
            </div>
            <div class="card-body">
                <div class="alert alert-info">
                    <i class="fas fa-rocket me-2"></i>
                    Добро пожаловать в вашу CRM систему! Здесь вы можете управлять проектами, клиентами и финансами.
                </div>
                
                <div class="row mt-4">
                    <div class="col-md-6">
                        <h5>Быстрые действия</h5>
                        <div class="d-grid gap-2">
                            <a href="<?= $base_url ?>/projects/create" class="btn btn-primary">
                                <i class="fas fa-plus me-1"></i>Создать проект
                            </a>
                            <a href="<?= $base_url ?>/finance/create" class="btn btn-success">
                                <i class="fas fa-money-bill me-1"></i>Добавить транзакцию
                            </a>
                            <a href="<?= $base_url ?>/clients/create" class="btn btn-info">
                                <i class="fas fa-user-plus me-1"></i>Добавить клиента
                            </a>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <h5>Статистика</h5>
                        <div class="list-group">
                            <div class="list-group-item d-flex justify-content-between">
                                <span>Активных проектов:</span>
                                <strong><?= $stats['active'] ?></strong>
                            </div>
                            <div class="list-group-item d-flex justify-content-between">
                                <span>Просроченных проектов:</span>
                                <strong class="text-danger"><?= $stats['overdue'] ?></strong>
                            </div>
                            <div class="list-group-item d-flex justify-content-between">
                                <span>Регулярных проектов:</span>
                                <strong><?= $stats['recurring'] ?></strong>
                            </div>
                            <div class="list-group-item d-flex justify-content-between">
                                <span>Общий доход за год:</span>
                                <strong class="text-success"><?= number_format($yearlyIncome, 2, ',', ' ') ?> ₽</strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>