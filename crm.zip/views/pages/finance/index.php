<div class="row">
    <div class="col-12">
        <!-- Статистика -->
        <div class="stats-grid mb-4">
            <div class="stat-card">
                <div class="stat-number text-success"><?= number_format($stats['income'], 2, ',', ' ') ?> ₽</div>
                <div class="stat-label">Доходы</div>
            </div>
            <div class="stat-card">
                <div class="stat-number text-danger"><?= number_format($stats['expenses'], 2, ',', ' ') ?> ₽</div>
                <div class="stat-label">Расходы</div>
            </div>
            <div class="stat-card">
                <div class="stat-number text-primary"><?= number_format($stats['profit'], 2, ',', ' ') ?> ₽</div>
                <div class="stat-label">Прибыль</div>
            </div>
            <div class="stat-card">
                <div class="stat-number text-warning"><?= number_format($stats['pending'], 2, ',', ' ') ?> ₽</div>
                <div class="stat-label">Ожидает оплаты</div>
            </div>
            <div class="stat-card">
                <div class="stat-number text-info"><?= $stats['total'] ?></div>
                <div class="stat-label">Транзакций</div>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-money-bill-wave me-2"></i>Финансы</h3>
                <a href="<?= $base_url ?>/finance/create" class="btn btn-primary btn-sm">
                    <i class="fas fa-plus me-1"></i>Добавить транзакцию
                </a>
            </div>
        </div>

<!-- Заменяем старый блок фильтров на этот -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0">
            <button class="btn btn-link p-0 text-decoration-none" type="button" data-bs-toggle="collapse" data-bs-target="#filtersCollapse">
                <i class="fas fa-filter me-2"></i>Фильтры
                <i class="fas fa-chevron-down ms-2 small"></i>
            </button>
        </h5>
    </div>
    <div class="collapse" id="filtersCollapse">
        <div class="card-body">
            <form method="GET" action="<?= $base_url ?>/finance">
                <div class="row g-3">
                    <div class="col-md-2">
                        <label class="form-label">Тип</label>
                        <select class="form-select" name="type">
                            <option value="">Все типы</option>
                            <option value="income" <?= $filters['type'] == 'income' ? 'selected' : '' ?>>Доходы</option>
                            <option value="expense" <?= $filters['type'] == 'expense' ? 'selected' : '' ?>>Расходы</option>
                        </select>
                    </div>
                    
                    <div class="col-md-2">
                        <label class="form-label">Статус</label>
                        <select class="form-select" name="status">
                            <option value="">Все статусы</option>
                            <option value="completed" <?= $filters['status'] == 'completed' ? 'selected' : '' ?>>Завершено</option>
                            <option value="pending" <?= $filters['status'] == 'pending' ? 'selected' : '' ?>>Ожидает</option>
                            <option value="cancelled" <?= $filters['status'] == 'cancelled' ? 'selected' : '' ?>>Отменено</option>
                        </select>
                    </div>
                    
                    <div class="col-md-2">
                        <label class="form-label">Проект</label>
                        <select class="form-select" name="project_id">
                            <option value="">Все проекты</option>
                            <?php foreach ($projects as $project): ?>
                                <option value="<?= $project['id'] ?>" <?= $filters['project_id'] == $project['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($project['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-2">
                        <label class="form-label">Дата от</label>
                        <input type="date" class="form-control" name="date_from" value="<?= $filters['date_from'] ?>">
                    </div>
                    
                    <div class="col-md-2">
                        <label class="form-label">Дата до</label>
                        <input type="date" class="form-control" name="date_to" value="<?= $filters['date_to'] ?>">
                    </div>
                    
                    <div class="col-md-2">
                        <label class="form-label">Поиск</label>
                        <input type="text" class="form-control" name="search" value="<?= $filters['search'] ?>" placeholder="Поиск...">
                    </div>
                    
                    <div class="col-md-12">
                        <div class="d-flex gap-2 mt-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-filter me-1"></i>Применить фильтры
                            </button>
                            <a href="<?= $base_url ?>/finance" class="btn btn-secondary">
                                <i class="fas fa-times me-1"></i>Сбросить
                            </a>
                            <button type="button" class="btn btn-outline-success" onclick="exportFinance()">
                                <i class="fas fa-download me-1"></i>Экспорт
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

        <!-- Все транзакции -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-history me-2"></i>Все транзакции</h5>
            </div>
            <div class="card-body">
                <?php if (empty($transactions)): ?>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Транзакций не найдено.
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Дата</th>
                                    <th>Проект</th>
                                   
                                    <th>Тип</th>
                                    <th>Сумма</th>
                                    <th>Статус</th>
                                    <th>Описание</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($transactions as $transaction): ?>
                                <tr>
                                    <td><?= date('d.m.Y', strtotime($transaction['payment_date'])) ?></td>
                                    <td>
                                        <strong><?= htmlspecialchars($transaction['project_name'] ?? 'Не указан') ?></strong>
                                    </td>
                                    
                                    <td>
                                        <?php if ($transaction['type'] === 'income'): ?>
                                            <span class="badge bg-success">Доход</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Расход</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="fw-bold <?= $transaction['type'] === 'income' ? 'text-success' : 'text-danger' ?>">
                                            <?= number_format($transaction['amount'], 2, ',', ' ') ?> ₽
                                        </span>
                                    </td>
                                    <td>
                                        <?php
                                        $status_badges = [
                                            'pending' => ['warning', 'Ожидает'],
                                            'completed' => ['success', 'Завершено'],
                                            'cancelled' => ['danger', 'Отменено']
                                        ];
                                        ?>
                                        <span class="badge bg-<?= $status_badges[$transaction['status']][0] ?>">
                                            <?= $status_badges[$transaction['status']][1] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if (!empty($transaction['description'])): ?>
                                            <small class="text-muted"><?= htmlspecialchars(substr($transaction['description'], 0, 50)) ?>...</small>
                                        <?php else: ?>
                                            <span class="text-muted">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?= $base_url ?>/finance/view?id=<?= $transaction['id'] ?>" class="btn btn-sm btn-outline-info">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?= $base_url ?>/finance/edit?id=<?= $transaction['id'] ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="<?= $base_url ?>/finance/delete?id=<?= $transaction['id'] ?>" 
                                               class="btn btn-sm btn-outline-danger" 
                                               onclick="return confirm('Удалить транзакцию?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
function exportFinance() {
    // Создаем URL с текущими параметрами фильтров
    const params = new URLSearchParams(window.location.search);
    params.set('export', 'csv');
    
    // Открываем в новом окне для скачивания
    window.open('<?= $base_url ?>/finance/export?' + params.toString(), '_blank');
}

// Инициализация фильтров при загрузке
document.addEventListener('DOMContentLoaded', function() {
    // Автозаполнение дат
    const today = new Date().toISOString().split('T')[0];
    const firstDayOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 2).toISOString().split('T')[0];
    
    // Если даты не заполнены, предлагаем текущий месяц
    if (!document.querySelector('input[name="date_from"]').value) {
        document.querySelector('input[name="date_from"]').value = firstDayOfMonth;
    }
    if (!document.querySelector('input[name="date_to"]').value) {
        document.querySelector('input[name="date_to"]').value = today;
    }
});
</script>