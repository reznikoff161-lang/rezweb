<div class="row">
    <div class="col-lg-8">
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="mb-0">Транзакция #<?= $transaction['id'] ?></h3>
                <div class="btn-group">
                    <a href="<?= $base_url ?>/finance/edit?id=<?= $transaction['id'] ?>" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-edit me-1"></i>Редактировать
                    </a>
                    <a href="<?= $base_url ?>/finance" class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-arrow-left me-1"></i>Назад
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <strong>Сумма:</strong><br>
                            <span class="fw-bold fs-4 <?= $transaction['type'] === 'income' ? 'text-success' : 'text-danger' ?>">
                                <?= number_format($transaction['amount'], 2, ',', ' ') ?> ₽
                            </span>
                        </div>
                        
                        <div class="mb-3">
                            <strong>Тип операции:</strong><br>
                            <?php if ($transaction['type'] === 'income'): ?>
                                <span class="badge bg-success">Доход</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Расход</span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="mb-3">
                            <strong>Статус:</strong><br>
                            <?php
                            $status_badges = [
                                'pending' => ['warning', 'Ожидает'],
                                'completed' => ['success', 'Завершено'],
                                'cancelled' => ['danger', 'Отменено']
                            ];
                            ?>
                            <span class="badge bg-<?= $status_badges[$transaction['status']][0] ?>">
                                <?= $status_badges[$transaction['status']][1] ?>
                            </span>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="mb-3">
                            <strong>Дата операции:</strong><br>
                            <span class="text-muted">
                                <?= date('d.m.Y', strtotime($transaction['payment_date'])) ?>
                            </span>
                        </div>
                        
                        <div class="mb-3">
                            <strong>Способ оплаты:</strong><br>
                            <span class="text-muted">
                                <?php
                                $payment_methods = [
                                    'bank_transfer' => 'Банковский перевод',
                                    'cash' => 'Наличные',
                                    'card' => 'Карта',
                                    'online' => 'Онлайн'
                                ];
                                echo $payment_methods[$transaction['payment_method']] ?? 'Не указан';
                                ?>
                            </span>
                        </div>
                        
                        <div class="mb-3">
                            <strong>Проект:</strong><br>
                            <span class="text-muted">
                                <?= $project ? htmlspecialchars($project['name']) : 'Не указан' ?>
                            </span>
                        </div>
                    </div>
                </div>

                <?php if (!empty($transaction['description'])): ?>
                    <div class="mt-3">
                        <strong>Описание:</strong>
                        <p class="text-muted"><?= nl2br(htmlspecialchars($transaction['description'])) ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <!-- Информация о клиенте -->
        <?php if ($client): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Клиент</h5>
            </div>
            <div class="card-body">
                <h6><?= htmlspecialchars($client['name']) ?></h6>
                <?php if (!empty($client['company'])): ?>
                    <p class="text-muted"><?= htmlspecialchars($client['company']) ?></p>
                <?php endif; ?>
                
                <?php if (!empty($client['email'])): ?>
                    <div class="d-flex align-items-center mb-2">
                        <i class="fas fa-envelope text-muted me-2"></i>
                        <small><?= htmlspecialchars($client['email']) ?></small>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($client['phone'])): ?>
                    <div class="d-flex align-items-center mb-2">
                        <i class="fas fa-phone text-muted me-2"></i>
                        <small><?= htmlspecialchars($client['phone']) ?></small>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Действия -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Действия</h5>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="<?= $base_url ?>/finance/edit?id=<?= $transaction['id'] ?>" class="btn btn-primary">
                        <i class="fas fa-edit me-1"></i>Редактировать
                    </a>
                    <button class="btn btn-outline-danger" onclick="if(confirm('Удалить транзакцию?')) window.location='<?= $base_url ?>/finance/delete?id=<?= $transaction['id'] ?>'">
                        <i class="fas fa-trash me-1"></i>Удалить
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>