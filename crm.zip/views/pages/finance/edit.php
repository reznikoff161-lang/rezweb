<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-edit me-2"></i>Редактировать транзакцию</h3>
                <a href="<?= $base_url ?>/finance" class="btn btn-outline-secondary btn-sm">
                    <i class="fas fa-arrow-left me-1"></i>Назад
                </a>
            </div>
            <div class="card-body">
                <?php if (!empty($errors['general'])): ?>
                    <div class="alert alert-danger">
                        <?= htmlspecialchars($errors['general']) ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="<?= $base_url ?>/finance/edit?id=<?= $transaction['id'] ?>">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="project_id" class="form-label">Проект *</label>
                                <select class="form-control <?= !empty($errors['project_id']) ? 'is-invalid' : '' ?>" 
                                        id="project_id" name="project_id" required>
                                    <option value="">-- Выберите проект --</option>
                                    <?php foreach ($projects as $project): ?>
                                        <option value="<?= $project['id'] ?>" 
                                            <?= $formData['project_id'] == $project['id'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($project['name']) ?>
                                            <?= !empty($project['client_name']) ? ' (' . htmlspecialchars($project['client_name']) . ')' : '' ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <?php if (!empty($errors['project_id'])): ?>
                                    <div class="invalid-feedback"><?= htmlspecialchars($errors['project_id']) ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="amount" class="form-label">Сумма (₽) *</label>
                                <input type="number" step="0.01" class="form-control <?= !empty($errors['amount']) ? 'is-invalid' : '' ?>" 
                                       id="amount" name="amount" required 
                                       value="<?= htmlspecialchars($formData['amount']) ?>"
                                       placeholder="0.00">
                                <?php if (!empty($errors['amount'])): ?>
                                    <div class="invalid-feedback"><?= htmlspecialchars($errors['amount']) ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group mb-3">
                                <label for="type" class="form-label">Тип операции *</label>
                                <select class="form-control" id="type" name="type" required>
                                    <option value="income" <?= $formData['type'] == 'income' ? 'selected' : '' ?>>Доход</option>
                                    <option value="expense" <?= $formData['type'] == 'expense' ? 'selected' : '' ?>>Расход</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="form-group mb-3">
                                <label for="payment_method" class="form-label">Способ оплаты</label>
                                <select class="form-control" id="payment_method" name="payment_method">
                                    <option value="bank_transfer" <?= $formData['payment_method'] == 'bank_transfer' ? 'selected' : '' ?>>Банковский перевод</option>
                                    <option value="cash" <?= $formData['payment_method'] == 'cash' ? 'selected' : '' ?>>Наличные</option>
                                    <option value="card" <?= $formData['payment_method'] == 'card' ? 'selected' : '' ?>>Карта</option>
                                    <option value="online" <?= $formData['payment_method'] == 'online' ? 'selected' : '' ?>>Онлайн</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="form-group mb-3">
                                <label for="status" class="form-label">Статус *</label>
                                <select class="form-control" id="status" name="status" required>
                                    <option value="completed" <?= $formData['status'] == 'completed' ? 'selected' : '' ?>>Завершено</option>
                                    <option value="pending" <?= $formData['status'] == 'pending' ? 'selected' : '' ?>>Ожидает</option>
                                    <option value="cancelled" <?= $formData['status'] == 'cancelled' ? 'selected' : '' ?>>Отменено</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="payment_date" class="form-label">Дата операции *</label>
                                <input type="date" class="form-control <?= !empty($errors['payment_date']) ? 'is-invalid' : '' ?>" 
                                       id="payment_date" name="payment_date" required 
                                       value="<?= htmlspecialchars($formData['payment_date']) ?>">
                                <?php if (!empty($errors['payment_date'])): ?>
                                    <div class="invalid-feedback"><?= htmlspecialchars($errors['payment_date']) ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group mb-3">
                        <label for="description" class="form-label">Описание</label>
                        <textarea class="form-control" id="description" name="description" 
                                  rows="3" placeholder="Описание транзакции"><?= htmlspecialchars($formData['description']) ?></textarea>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Сохранить изменения
                        </button>
                        <a href="<?= $base_url ?>/finance" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i>Отмена
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>