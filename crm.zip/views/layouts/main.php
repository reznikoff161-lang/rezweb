<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?? 'Моя CRM' ?></title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Наши стили -->
    <link href="<?= BASE_URL ?>/assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-brand">
                <h1><i class="fas fa-palette"></i> Моя Студия</h1>
            </div>
            <nav>
                <ul class="sidebar-nav">
                    <li class="sidebar-nav-item">
                        <a href="<?= BASE_URL ?>/" class="sidebar-nav-link active">
                            <i class="sidebar-nav-icon fas fa-home"></i>
                            Главная
                        </a>
                    </li>
                    <li class="sidebar-nav-item">
                        <a href="<?= BASE_URL ?>/projects" class="sidebar-nav-link">
                            <i class="sidebar-nav-icon fas fa-briefcase"></i>
                            Проекты
                        </a>
                    </li>
                    <li class="sidebar-nav-item">
                        <a href="<?= BASE_URL ?>/finance" class="sidebar-nav-link">
                            <i class="sidebar-nav-icon fas fa-chart-line"></i>
                            Финансы
                        </a>
                    </li>
                    <li class="sidebar-nav-item">
                        <a href="<?= BASE_URL ?>/statistics" class="sidebar-nav-link">
                            <i class="sidebar-nav-icon fas fa-chart-pie"></i>
                            Статистика
                        </a>
                    </li>
                    <li class="sidebar-nav-item">
                        <a href="<?= BASE_URL ?>/logout" class="sidebar-nav-link">
                            <i class="sidebar-nav-icon fas fa-sign-out-alt"></i>
                            Выход
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- Main content -->
        <main class="main-content">
            <header class="content-header">
                <h2><?= $page_title ?? 'Главная' ?></h2>
                <div class="user-info">
                    <span class="text-muted"><?= $_SESSION['user_login'] ?? 'Пользователь' ?></span>
                </div>
            </header>

            <?= $content ?? '' ?>
        </main>
    </div>

    <!-- Bootstrap & Alpine JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="//unpkg.com/alpinejs" defer></script>
    <script src="<?= BASE_URL ?>/assets/js/script.js"></script>
</body>
</html>