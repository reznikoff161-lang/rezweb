<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?? 'Моя CRM' ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="<?= BASE_URL ?>/assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="app-container">
        <!-- Sidebar - now works as bottom menu on mobile -->
        <aside class="sidebar">
            <div class="sidebar-brand">
                <h1><i class="fas fa-palette"></i> Моя Студия</h1>
            </div>
            <nav>
                <ul class="sidebar-nav">
                    <li class="sidebar-nav-item">
                        <a href="<?= BASE_URL ?>/" class="sidebar-nav-link <?= ($current_page == 'home') ? 'active' : '' ?>">
                            <i class="sidebar-nav-icon fas fa-home"></i>
                            <span class="sidebar-nav-text">Главная</span>
                        </a>
                    </li>
                    <li class="sidebar-nav-item">
                        <a href="<?= BASE_URL ?>/projects" class="sidebar-nav-link <?= ($current_page == 'projects') ? 'active' : '' ?>">
                            <i class="sidebar-nav-icon fas fa-briefcase"></i>
                            <span class="sidebar-nav-text">Проекты</span>
                        </a>
                    </li>
                    <li class="sidebar-nav-item">
                        <a href="<?= BASE_URL ?>/clients" class="sidebar-nav-link <?= ($current_page == 'clients') ? 'active' : '' ?>">
                            <i class="sidebar-nav-icon fas fa-users"></i>
                            <span class="sidebar-nav-text">Клиенты</span>
                        </a>
                    </li>
                    <li class="sidebar-nav-item">
                        <a href="<?= BASE_URL ?>/finance" class="sidebar-nav-link <?= ($current_page == 'finance') ? 'active' : '' ?>">
                            <i class="sidebar-nav-icon fas fa-chart-line"></i>
                            <span class="sidebar-nav-text">Финансы</span>
                        </a>
                    </li>

                    <li class="sidebar-nav-item">
                        <a href="<?= BASE_URL ?>/statistics" class="sidebar-nav-link <?= ($current_page == 'statistics') ? 'active' : '' ?>">
                            <i class="sidebar-nav-icon fas fa-chart-pie"></i>
                            <span class="sidebar-nav-text">Статистика</span>
                        </a>
                    </li>
                    <li class="sidebar-nav-item">
                        <a href="<?= BASE_URL ?>/logout" class="sidebar-nav-link">
                            <i class="sidebar-nav-icon fas fa-sign-out-alt"></i>
                            <span class="sidebar-nav-text">Выход</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- Main content -->
        <main class="main-content">
            <header class="content-header">
                <h2><?= $page_title ?></h2>
                    <div class="user-info">
                        <div class="user-profile">
                            <div class="user-avatar">
                                <?= strtoupper(substr($_SESSION['user_login'] ?? 'A', 0, 1)) ?>
                            </div>
                            <div class="user-details">
                                <div class="fw-small"><?= $_SESSION['user_login'] ?? 'Пользователь' ?></div>
                                <div class="text-muted" style="font-size: 0.75rem;">Администратор</div>
                            </div>
                        </div>
                    </div>
            </header>

            <?= $content ?? '' ?>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?= BASE_URL ?>/assets/js/script.js"></script>
    
    <script>
    // JavaScript для правильного выделения активного пункта меню
    document.addEventListener('DOMContentLoaded', function() {
        const currentPath = window.location.pathname;
        const navLinks = document.querySelectorAll('.sidebar-nav-link');
        
        navLinks.forEach(link => {
            const href = link.getAttribute('href');
            // Убираем BASE_URL из сравнения
            const linkPath = href.replace('<?= BASE_URL ?>', '');
            const cleanCurrentPath = currentPath.replace('<?= BASE_URL ?>', '');
            
            if (cleanCurrentPath === linkPath || 
                (cleanCurrentPath === '/' && linkPath === '/') ||
                (cleanCurrentPath.startsWith(linkPath) && linkPath !== '/')) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    });
    </script>
</body>
</html>