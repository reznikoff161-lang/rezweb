// Mobile menu handling
document.addEventListener('DOMContentLoaded', function() {
    // Auto-show sidebar on mobile
    if (window.innerWidth < 769) {
        document.querySelector('.sidebar').style.display = 'block';
    }
    
    // Handle window resize
    window.addEventListener('resize', function() {
        if (window.innerWidth < 769) {
            document.querySelector('.sidebar').style.display = 'block';
        } else {
            document.querySelector('.sidebar').style.display = 'block';
        }
    });
    
    // Active page highlighting
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.sidebar-nav-link');
    
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href && currentPath.includes(href.replace(BASE_URL, ''))) {
            link.classList.add('active');
        }
    });
});

// Constants
const BASE_URL = '/crm'; // Should match your PHP constant