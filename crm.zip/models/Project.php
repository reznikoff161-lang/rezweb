<?php
class Project {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    // Создать новый проект
    public function create($data) {
        $sql = "INSERT INTO projects (name, description, client_name, client_id, service_id, price, status, deadline, start_date, is_recurring, recurrence_type) 
                VALUES (:name, :description, :client_name, :client_id, :service_id, :price, :status, :deadline, :start_date, :is_recurring, :recurrence_type)";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':name' => $data['name'],
            ':description' => $data['description'],
            ':client_name' => $data['client_name'],
            ':client_id' => $data['client_id'] ?? null,
            ':service_id' => $data['service_id'] ?? null,
            ':price' => $data['price'],
            ':status' => $data['status'],
            ':deadline' => !empty($data['deadline']) ? $data['deadline'] : null,
            ':start_date' => $data['start_date'],
            ':is_recurring' => $data['is_recurring'] ?? 0,
            ':recurrence_type' => $data['recurrence_type'] ?? null
        ]);
    }
    
    // Получить все проекты с информацией об услугах и клиентах
    public function getAll() {
        $sql = "SELECT p.*, s.name as service_name, c.name as client_company 
                FROM projects p 
                LEFT JOIN services s ON p.service_id = s.id 
                LEFT JOIN clients c ON p.client_id = c.id 
                ORDER BY p.created_at DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    // Получить проект по ID
    public function getById($id) {
        $sql = "SELECT p.*, s.name as service_name, c.name as client_company 
                FROM projects p 
                LEFT JOIN services s ON p.service_id = s.id 
                LEFT JOIN clients c ON p.client_id = c.id 
                WHERE p.id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }
    
    // Обновить проект
    public function update($id, $data) {
        $sql = "UPDATE projects SET 
                name = :name, 
                description = :description, 
                client_name = :client_name, 
                client_id = :client_id, 
                service_id = :service_id, 
                price = :price, 
                status = :status, 
                deadline = :deadline, 
                start_date = :start_date,
                is_recurring = :is_recurring,
                recurrence_type = :recurrence_type
                WHERE id = :id";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':id' => $id,
            ':name' => $data['name'],
            ':description' => $data['description'],
            ':client_name' => $data['client_name'],
            ':client_id' => $data['client_id'] ?? null,
            ':service_id' => $data['service_id'] ?? null,
            ':price' => $data['price'],
            ':status' => $data['status'],
            ':deadline' => !empty($data['deadline']) ? $data['deadline'] : null,
            ':start_date' => $data['start_date'],
            ':is_recurring' => $data['is_recurring'] ?? 0,
            ':recurrence_type' => $data['recurrence_type'] ?? null
        ]);
    }
    
    // Удалить проект
    public function delete($id) {
        $sql = "DELETE FROM projects WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }
    
    // Получить проекты по статусу
    public function getByStatus($status) {
        $sql = "SELECT p.*, s.name as service_name, c.name as client_company 
                FROM projects p 
                LEFT JOIN services s ON p.service_id = s.id 
                LEFT JOIN clients c ON p.client_id = c.id 
                WHERE p.status = :status 
                ORDER BY p.deadline ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':status' => $status]);
        return $stmt->fetchAll();
    }
    
    // Получить количество проектов по статусам
    public function getCountByStatus() {
        $sql = "SELECT status, COUNT(*) as count FROM projects GROUP BY status";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    // Получить проекты с просроченным дедлайном
    public function getOverdueProjects() {
        $sql = "SELECT p.*, s.name as service_name, c.name as client_company 
                FROM projects p 
                LEFT JOIN services s ON p.service_id = s.id 
                LEFT JOIN clients c ON p.client_id = c.id 
                WHERE p.deadline IS NOT NULL 
                AND p.deadline < CURDATE() 
                AND p.status NOT IN ('completed', 'cancelled')
                ORDER BY p.deadline ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    // Получить регулярные (рекуррентные) проекты
    public function getRecurringProjects() {
        $sql = "SELECT p.*, s.name as service_name, c.name as client_company 
                FROM projects p 
                LEFT JOIN services s ON p.service_id = s.id 
                LEFT JOIN clients c ON p.client_id = c.id 
                WHERE p.is_recurring = 1 
                ORDER BY p.name ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    // Получить проекты по услуге
    public function getByService($service_id) {
        $sql = "SELECT p.*, s.name as service_name, c.name as client_company 
                FROM projects p 
                LEFT JOIN services s ON p.service_id = s.id 
                LEFT JOIN clients c ON p.client_id = c.id 
                WHERE p.service_id = :service_id 
                ORDER BY p.created_at DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':service_id' => $service_id]);
        return $stmt->fetchAll();
    }
    
    // Получить проекты по клиенту
    public function getByClient($client_id) {
        $sql = "SELECT p.*, s.name as service_name, c.name as client_company 
                FROM projects p 
                LEFT JOIN services s ON p.service_id = s.id 
                LEFT JOIN clients c ON p.client_id = c.id 
                WHERE p.client_id = :client_id 
                ORDER BY p.created_at DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':client_id' => $client_id]);
        return $stmt->fetchAll();
    }
    
    // Поиск проектов
    public function search($query) {
        $sql = "SELECT p.*, s.name as service_name, c.name as client_company 
                FROM projects p 
                LEFT JOIN services s ON p.service_id = s.id 
                LEFT JOIN clients c ON p.client_id = c.id 
                WHERE p.name LIKE :query 
                OR p.description LIKE :query 
                OR p.client_name LIKE :query 
                OR c.name LIKE :query 
                OR s.name LIKE :query 
                ORDER BY p.created_at DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':query' => '%' . $query . '%']);
        return $stmt->fetchAll();
    }
    
    // НОВЫЕ МЕТОДЫ ДЛЯ ФИНАНСОВ
    // Получить общую сумму оплат по проекту
    public function getTotalPaid($project_id) {
        $sql = "SELECT SUM(amount) as total_paid 
                FROM transactions 
                WHERE project_id = :project_id 
                AND type = 'income' 
                AND status = 'completed'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':project_id' => $project_id]);
        $result = $stmt->fetch();
        return $result['total_paid'] ?? 0;
    }
    
    // Получить остаток к оплате
    public function getBalance($project_id) {
        $project = $this->getById($project_id);
        $total_paid = $this->getTotalPaid($project_id);
        return $project['price'] - $total_paid;
    }
    
    // Получить статус оплаты
    public function getPaymentStatus($project_id) {
        $balance = $this->getBalance($project_id);
        $project = $this->getById($project_id);
        
        if ($balance <= 0) {
            return 'paid'; // Полностью оплачен
        } elseif ($balance < $project['price']) {
            return 'partial'; // Частично оплачен
        } else {
            return 'unpaid'; // Не оплачен
        }
    }
}
?>