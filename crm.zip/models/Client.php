<?php
class Client {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function create($data) {
        $sql = "INSERT INTO clients (name, email, phone, company, contact_person, notes) 
                VALUES (:name, :email, :phone, :company, :contact_person, :notes)";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':name' => $data['name'],
            ':email' => $data['email'],
            ':phone' => $data['phone'],
            ':company' => $data['company'],
            ':contact_person' => $data['contact_person'],
            ':notes' => $data['notes']
        ]);
    }
    
    public function getAll() {
        $sql = "SELECT * FROM clients ORDER BY created_at DESC"; // Сортировка по дате создания
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    public function getById($id) {
        $sql = "SELECT * FROM clients WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }
    
    public function update($id, $data) {
        $sql = "UPDATE clients SET 
                name = :name, 
                email = :email, 
                phone = :phone, 
                company = :company, 
                contact_person = :contact_person, 
                notes = :notes 
                WHERE id = :id";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':id' => $id,
            ':name' => $data['name'],
            ':email' => $data['email'],
            ':phone' => $data['phone'],
            ':company' => $data['company'],
            ':contact_person' => $data['contact_person'],
            ':notes' => $data['notes']
        ]);
    }
    
    public function delete($id) {
        $sql = "DELETE FROM clients WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }
    
    public function search($query) {
        $sql = "SELECT * FROM clients 
                WHERE name LIKE :query 
                OR email LIKE :query 
                OR company LIKE :query 
                OR contact_person LIKE :query 
                ORDER BY name ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':query' => '%' . $query . '%']);
        return $stmt->fetchAll();
    }
}
?>