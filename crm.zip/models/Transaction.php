<?php
class Transaction {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    // Создать транзакцию
    public function create($data) {
        $sql = "INSERT INTO transactions (project_id, amount, type, payment_method, status, payment_date, description) 
                VALUES (:project_id, :amount, :type, :payment_method, :status, :payment_date, :description)";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':project_id' => $data['project_id'],
            ':amount' => $data['amount'],
            ':type' => $data['type'],
            ':payment_method' => $data['payment_method'],
            ':status' => $data['status'],
            ':payment_date' => $data['payment_date'],
            ':description' => $data['description']
        ]);
    }
    
    // Получить все транзакции проекта
    public function getByProject($project_id) {
        $sql = "SELECT t.*, p.name as project_name 
                FROM transactions t 
                LEFT JOIN projects p ON t.project_id = p.id 
                WHERE t.project_id = :project_id 
                ORDER BY t.payment_date DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':project_id' => $project_id]);
        return $stmt->fetchAll();
    }
    
    // Получить все транзакции клиента
    public function getByClient($client_id) {
        $sql = "SELECT t.*, p.name as project_name, p.client_name 
                FROM transactions t 
                LEFT JOIN projects p ON t.project_id = p.id 
                WHERE p.client_id = :client_id 
                ORDER BY t.payment_date DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':client_id' => $client_id]);
        return $stmt->fetchAll();
    }
    
    // Получить транзакцию по ID
    public function getById($id) {
        $sql = "SELECT t.*, p.name as project_name, p.client_name 
                FROM transactions t 
                LEFT JOIN projects p ON t.project_id = p.id 
                WHERE t.id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }
    
    // Обновить транзакцию
    public function update($id, $data) {
        $sql = "UPDATE transactions SET 
                amount = :amount, 
                type = :type, 
                payment_method = :payment_method, 
                status = :status, 
                payment_date = :payment_date, 
                description = :description 
                WHERE id = :id";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':id' => $id,
            ':amount' => $data['amount'],
            ':type' => $data['type'],
            ':payment_method' => $data['payment_method'],
            ':status' => $data['status'],
            ':payment_date' => $data['payment_date'],
            ':description' => $data['description']
        ]);
    }
    
    // Удалить транзакцию
    public function delete($id) {
        $sql = "DELETE FROM transactions WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }
    
    // Получить сумму доходов по проекту
    public function getProjectIncome($project_id) {
        $sql = "SELECT SUM(amount) as total_income 
                FROM transactions 
                WHERE project_id = :project_id 
                AND type = 'income' 
                AND status = 'completed'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':project_id' => $project_id]);
        $result = $stmt->fetch();
        return $result['total_income'] ?? 0;
    }
    
    // Получить сумму расходов по проекту
    public function getProjectExpenses($project_id) {
        $sql = "SELECT SUM(amount) as total_expenses 
                FROM transactions 
                WHERE project_id = :project_id 
                AND type = 'expense' 
                AND status = 'completed'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':project_id' => $project_id]);
        $result = $stmt->fetch();
        return $result['total_expenses'] ?? 0;
    }
    
    // Получить финансовую статистику по проекту
    public function getProjectFinancialStats($project_id) {
        $income = $this->getProjectIncome($project_id);
        $expenses = $this->getProjectExpenses($project_id);
        $profit = $income - $expenses;
        
        return [
            'income' => $income,
            'expenses' => $expenses,
            'profit' => $profit,
            'balance' => $profit
        ];
    }
    
    // Получить ожидаемые платежи
    public function getPendingTransactions() {
        $sql = "SELECT t.*, p.name as project_name, p.client_name 
                FROM transactions t 
                LEFT JOIN projects p ON t.project_id = p.id 
                WHERE t.status = 'pending' 
                ORDER BY t.payment_date ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    // Получить все транзакции
    public function getAllTransactions($limit = 100) {
        $sql = "SELECT t.*, p.name as project_name, p.client_name 
                FROM transactions t 
                LEFT JOIN projects p ON t.project_id = p.id 
                ORDER BY t.payment_date DESC 
                LIMIT :limit";
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    // Поиск транзакций
    public function search($query) {
        $sql = "SELECT t.*, p.name as project_name, p.client_name 
                FROM transactions t 
                LEFT JOIN projects p ON t.project_id = p.id 
                WHERE p.name LIKE :query 
                OR p.client_name LIKE :query 
                OR t.description LIKE :query 
                ORDER BY t.payment_date DESC";
        $stmt = $this->db->prepare($sql);
        
        $searchPattern = '%' . $query . '%';
        $stmt->execute([':query' => $searchPattern]);
        
        return $stmt->fetchAll();
    }
    
    // НОВЫЕ МЕТОДЫ ДЛЯ ФИЛЬТРАЦИИ И СТАТИСТИКИ
    
    // Метод для получения отфильтрованных транзакций
    public function getFilteredTransactions($filters = []) {
        $sql = "SELECT t.*, p.name as project_name, p.client_name 
                FROM transactions t 
                LEFT JOIN projects p ON t.project_id = p.id 
                WHERE 1=1";
        
        $params = [];
        
        // Фильтр по типу
        if (!empty($filters['type'])) {
            $sql .= " AND t.type = :type";
            $params[':type'] = $filters['type'];
        }
        
        // Фильтр по статусу
        if (!empty($filters['status'])) {
            $sql .= " AND t.status = :status";
            $params[':status'] = $filters['status'];
        }
        
        // Фильтр по проекту
        if (!empty($filters['project_id'])) {
            $sql .= " AND t.project_id = :project_id";
            $params[':project_id'] = $filters['project_id'];
        }
        
        // Фильтр по дате от
        if (!empty($filters['date_from'])) {
            $sql .= " AND t.payment_date >= :date_from";
            $params[':date_from'] = $filters['date_from'];
        }
        
        // Фильтр по дате до
        if (!empty($filters['date_to'])) {
            $sql .= " AND t.payment_date <= :date_to";
            $params[':date_to'] = $filters['date_to'];
        }
        
        // Поиск
        if (!empty($filters['search'])) {
            $sql .= " AND (p.name LIKE :search OR p.client_name LIKE :search OR t.description LIKE :search)";
            $params[':search'] = '%' . $filters['search'] . '%';
        }
        
        $sql .= " ORDER BY t.payment_date DESC LIMIT 500";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    // Доход за период
public function getPeriodIncome($dateFrom, $dateTo) {
    $sql = "SELECT SUM(amount) as total_income 
            FROM transactions 
            WHERE type = 'income' 
            AND status = 'completed' 
            AND payment_date BETWEEN :date_from AND :date_to";
    
    $stmt = $this->db->prepare($sql);
    $stmt->execute([
        ':date_from' => $dateFrom,
        ':date_to' => $dateTo
    ]);
    
    $result = $stmt->fetch();
    return $result['total_income'] ?? 0;
}

// Ожидаемые доходы
public function getPendingIncome() {
    $sql = "SELECT SUM(amount) as total_pending 
            FROM transactions 
            WHERE type = 'income' 
            AND status = 'pending'";
    
    $stmt = $this->db->prepare($sql);
    $stmt->execute();
    
    $result = $stmt->fetch();
    return $result['total_pending'] ?? 0;
}
    // Метод для получения финансовой статистики
    public function getFinancialStats($filters = []) {
        $sql = "SELECT 
                    SUM(CASE WHEN type = 'income' AND status = 'completed' THEN amount ELSE 0 END) as total_income,
                    SUM(CASE WHEN type = 'expense' AND status = 'completed' THEN amount ELSE 0 END) as total_expenses,
                    SUM(CASE WHEN type = 'income' AND status = 'pending' THEN amount ELSE 0 END) as total_pending,
                    COUNT(*) as total_transactions
                FROM transactions t 
                LEFT JOIN projects p ON t.project_id = p.id 
                WHERE 1=1";
        
        $params = [];
        
        // Применяем те же фильтры
        if (!empty($filters['type'])) {
            $sql .= " AND t.type = :type";
            $params[':type'] = $filters['type'];
        }
        
        if (!empty($filters['status'])) {
            $sql .= " AND t.status = :status";
            $params[':status'] = $filters['status'];
        }
        
        if (!empty($filters['project_id'])) {
            $sql .= " AND t.project_id = :project_id";
            $params[':project_id'] = $filters['project_id'];
        }
        
        if (!empty($filters['date_from'])) {
            $sql .= " AND t.payment_date >= :date_from";
            $params[':date_from'] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $sql .= " AND t.payment_date <= :date_to";
            $params[':date_to'] = $filters['date_to'];
        }
        
        if (!empty($filters['search'])) {
            $sql .= " AND (p.name LIKE :search OR p.client_name LIKE :search OR t.description LIKE :search)";
            $params[':search'] = '%' . $filters['search'] . '%';
        }
        

        
        return [
            'income' => $result['total_income'] ?? 0,
            'expenses' => $result['total_expenses'] ?? 0,
            'pending' => $result['total_pending'] ?? 0,
            'profit' => ($result['total_income'] ?? 0) - ($result['total_expenses'] ?? 0),
            'total' => $result['total_transactions'] ?? 0
        ];
    }
}
?>