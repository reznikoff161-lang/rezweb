<?php
// /core/Template.php
class Template {
    private $dir;
    private $data = [];

    public function __construct($viewsDir) {
        $this->dir = rtrim($viewsDir, '/');
    }

    public function assign($key, $value) {
        $this->data[$key] = $value;
    }

    public function render($viewFile, $return = false) {
        $path = $this->dir . '/' . $viewFile . '.php';

        if (!file_exists($path)) {
            throw new Exception('Шаблон ' . $viewFile . ' не найден.');
        }

        // Импортируем переменные из массива $data в текущую область видимости
        extract($this->data);

        // Включаем буферизацию вывода
        ob_start();
        include($path);
        $content = ob_get_clean();

        if ($return) {
            return $content;
        } else {
            echo $content;
        }
    }
}
?>